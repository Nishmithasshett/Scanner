import gymnasium as gym
from gymnasium import spaces
import numpy as np
from typing import Dict, Any, Tuple, Optional, List
from loguru import logger
import random

class VulnerabilityScannersEnv(gym.Env):
    """
    OpenAI Gym environment for vulnerability scanning using RL.
    
    State: Current request features + scanning progress
    Actions: Different scanning/attack vector selections
    Rewards: Based on detection accuracy and fix suggestions
    """
    
    def __init__(self, dataset_features: np.ndarray, dataset_labels: np.ndarray, 
                 vulnerability_types: Dict[int, str]):
        super().__init__()
        
        self.dataset_features = dataset_features
        self.dataset_labels = dataset_labels
        self.vulnerability_types = vulnerability_types
        self.n_samples = len(dataset_features)
        self.feature_dim = dataset_features.shape[1]
        
        # Action space: different scanning techniques
        self.action_space = spaces.Discrete(10)  # 10 different scanning actions
        self.action_names = {
            0: 'sqli_probe',
            1: 'xss_payload',
            2: 'csrf_check',
            3: 'path_traversal',
            4: 'buffer_overflow_test',
            5: 'format_string_test',
            6: 'ldap_injection',
            7: 'xpath_injection',
            8: 'code_injection',
            9: 'comprehensive_scan'
        }
        
        # State space: request features + scanning progress
        # Features + [current_sample_idx, actions_taken, confidence_scores...]
        state_dim = self.feature_dim + 5  # features + progress indicators
        self.observation_space = spaces.Box(
            low=-np.inf, high=np.inf, shape=(state_dim,), dtype=np.float32
        )
        
        # Episode parameters
        self.max_steps = 20
        self.current_step = 0
        self.current_sample_idx = 0
        self.actions_taken = []
        self.confidence_scores = []
        
        # Reward tracking
        self.total_reward = 0
        self.correct_detections = 0
        self.false_positives = 0
        
        logger.info(f"Initialized RL environment with {self.n_samples} samples")
    
    def reset(self, seed: Optional[int] = None, options: Optional[Dict] = None) -> Tuple[np.ndarray, Dict]:
        """Reset the environment to initial state."""
        super().reset(seed=seed)
        
        self.current_step = 0
        self.current_sample_idx = np.random.randint(0, self.n_samples)
        self.actions_taken = []
        self.confidence_scores = []
        self.total_reward = 0
        
        state = self._get_state()
        info = self._get_info()
        
        return state.astype(np.float32), info
    
    def step(self, action: int) -> Tuple[np.ndarray, float, bool, bool, Dict]:
        """Execute one step in the environment."""
        self.current_step += 1
        self.actions_taken.append(action)
        
        # Get current sample
        current_features = self.dataset_features[self.current_sample_idx]
        true_label = self.dataset_labels[self.current_sample_idx]
        
        # Calculate reward based on action effectiveness
        reward = self._calculate_reward(action, current_features, true_label)
        self.total_reward += reward
        
        # Update confidence scores based on action
        confidence = self._get_action_confidence(action, current_features)
        self.confidence_scores.append(confidence)
        
        # Check if episode is done
        terminated = self.current_step >= self.max_steps
        truncated = False
        
        # Get next state
        if not terminated:
            # Move to next sample or stay with current one based on action
            if action == 9 or len(self.actions_taken) >= 3:  # comprehensive scan or enough actions
                self.current_sample_idx = np.random.randint(0, self.n_samples)
                self.actions_taken = []
                self.confidence_scores = []
        
        state = self._get_state()
        info = self._get_info()
        
        return state.astype(np.float32), reward, terminated, truncated, info
    
    def _get_state(self) -> np.ndarray:
        """Get current state representation."""
        current_features = self.dataset_features[self.current_sample_idx]
        
        # Progress indicators
        progress_features = np.array([
            self.current_sample_idx / self.n_samples,  # sample progress
            len(self.actions_taken) / 10,  # actions taken ratio
            np.mean(self.confidence_scores) if self.confidence_scores else 0,  # avg confidence
            self.current_step / self.max_steps,  # step progress
            len(set(self.actions_taken)) / 10  # action diversity
        ])
        
        state = np.concatenate([current_features, progress_features])
        return state
    
    def _calculate_reward(self, action: int, features: np.ndarray, true_label: int) -> float:
        """Calculate reward based on action effectiveness."""
        base_reward = 0
        
        # Get action effectiveness for this type of vulnerability
        action_effectiveness = self._get_action_effectiveness(action, features, true_label)
        
        if true_label == 0:  # Normal request
            if action_effectiveness < 0.3:  # Low false positive
                base_reward = 1.0
            else:  # High false positive
                base_reward = -1.0
                self.false_positives += 1
        else:  # Anomalous request
            if action_effectiveness > 0.7:  # Correct detection
                base_reward = 1.0
                self.correct_detections += 1
                
                # Bonus for suggesting correct fix
                if self._suggests_correct_fix(action, true_label):
                    base_reward += 2.0
            else:  # Missed detection
                base_reward = -0.5
        
        # Penalty for redundant actions
        if self.actions_taken.count(action) > 1:
            base_reward -= 0.2
        
        # Bonus for action diversity
        if len(set(self.actions_taken)) > 3:
            base_reward += 0.1
        
        return base_reward
    
    def _get_action_effectiveness(self, action: int, features: np.ndarray, true_label: int) -> float:
        """Calculate how effective an action is for detecting a specific vulnerability."""
        # Simplified effectiveness calculation based on feature patterns
        effectiveness_map = {
            0: features[6] * 0.8 + features[7] * 0.2,  # SQL injection probe
            1: features[5] * 0.7 + features[8] * 0.3,  # XSS payload
            2: features[2] * 0.6 + features[4] * 0.4,  # CSRF check
            3: features[9] * 0.8 + features[10] * 0.2,  # Path traversal
            4: features[11] * 0.9,  # Buffer overflow
            5: features[12] * 0.9,  # Format string
            6: features[13] * 0.8,  # LDAP injection
            7: features[14] * 0.8,  # XPath injection
            8: features[15] * 0.8,  # Code injection
            9: np.mean(features) * 0.6  # Comprehensive scan
        }
        
        base_effectiveness = effectiveness_map.get(action, 0.5)
        
        # Add noise and normalize
        effectiveness = np.clip(base_effectiveness + np.random.normal(0, 0.1), 0, 1)
        
        return effectiveness
    
    def _get_action_confidence(self, action: int, features: np.ndarray) -> float:
        """Get confidence score for an action."""
        return self._get_action_effectiveness(action, features, 0) + np.random.normal(0, 0.05)
    
    def _suggests_correct_fix(self, action: int, true_label: int) -> bool:
        """Check if action suggests the correct fix for the vulnerability type."""
        # Simplified mapping of actions to vulnerability types they can fix
        fix_mapping = {
            0: [1],  # SQL injection probe fixes SQL injection
            1: [2],  # XSS payload fixes XSS
            2: [3],  # CSRF check fixes CSRF
            3: [4],  # Path traversal fixes traversal
            4: [5],  # Buffer overflow test fixes buffer overflow
            5: [6],  # Format string test fixes format string
            6: [7],  # LDAP injection fixes LDAP injection
            7: [8],  # XPath injection fixes XPath injection
            8: [9],  # Code injection fixes code injection
            9: list(range(1, 10))  # Comprehensive scan can suggest fixes for all
        }
        
        return true_label in fix_mapping.get(action, [])
    
    def _get_info(self) -> Dict[str, Any]:
        """Get additional information about the current state."""
        return {
            'current_sample_idx': self.current_sample_idx,
            'current_step': self.current_step,
            'actions_taken': self.actions_taken.copy(),
            'confidence_scores': self.confidence_scores.copy(),
            'total_reward': self.total_reward,
            'correct_detections': self.correct_detections,
            'false_positives': self.false_positives,
            'true_label': self.dataset_labels[self.current_sample_idx],
            'vulnerability_type': self.vulnerability_types.get(
                self.dataset_labels[self.current_sample_idx], 'unknown'
            )
        }
    
    def render(self, mode: str = 'human') -> Optional[str]:
        """Render the environment state."""
        if mode == 'human':
            info = self._get_info()
            output = f"""
            Step: {self.current_step}/{self.max_steps}
            Sample: {self.current_sample_idx}
            True Label: {info['vulnerability_type']}
            Actions Taken: {[self.action_names[a] for a in self.actions_taken]}
            Total Reward: {self.total_reward:.2f}
            Correct Detections: {self.correct_detections}
            False Positives: {self.false_positives}
            """
            print(output)
            return output
        return None

class AttackSimulator:
    """Simulates different attack vectors for testing vulnerability detection."""
    
    def __init__(self):
        self.attack_patterns = {
            'sqli': [
                "' OR '1'='1",
                "'; DROP TABLE users; --",
                "' UNION SELECT * FROM users --",
                "1' AND 1=1 --",
                "admin'--"
            ],
            'xss': [
                "<script>alert('XSS')</script>",
                "javascript:alert('XSS')",
                "<img src=x onerror=alert('XSS')>",
                "<svg onload=alert('XSS')>",
                "';alert('XSS');//"
            ],
            'csrf': [
                "<form action='http://evil.com/transfer' method='post'>",
                "<img src='http://bank.com/transfer?amount=1000&to=attacker'>",
                "fetch('/api/delete', {method: 'POST'})"
            ],
            'traversal': [
                "../../../etc/passwd",
                "..\\..\\..\\windows\\system32\\config\\sam",
                "....//....//....//etc/passwd",
                "%2e%2e%2f%2e%2e%2f%2e%2e%2fetc%2fpasswd"
            ]
        }
    
    def generate_attack_payload(self, attack_type: str) -> str:
        """Generate a random attack payload of specified type."""
        if attack_type in self.attack_patterns:
            return random.choice(self.attack_patterns[attack_type])
        return ""
    
    def simulate_scan_action(self, action: int, target_features: np.ndarray) -> Dict[str, Any]:
        """Simulate the execution of a scanning action."""
        action_names = {
            0: 'sqli_probe',
            1: 'xss_payload', 
            2: 'csrf_check',
            3: 'path_traversal',
            4: 'buffer_overflow_test',
            5: 'format_string_test',
            6: 'ldap_injection',
            7: 'xpath_injection',
            8: 'code_injection',
            9: 'comprehensive_scan'
        }
        
        action_name = action_names.get(action, 'unknown')
        
        # Simulate scan results
        result = {
            'action': action_name,
            'payload_used': self.generate_attack_payload(action_name.split('_')[0]),
            'success_probability': np.random.random(),
            'confidence': np.random.random(),
            'detected_vulnerabilities': [],
            'recommended_fixes': []
        }
        
        # Add vulnerability detection based on features
        if target_features[6] > 0.5 and action in [0, 9]:  # SQL injection indicators
            result['detected_vulnerabilities'].append('SQL Injection')
            result['recommended_fixes'].append('Use parameterized queries')
        
        if target_features[5] > 0.5 and action in [1, 9]:  # XSS indicators
            result['detected_vulnerabilities'].append('Cross-Site Scripting')
            result['recommended_fixes'].append('Implement input validation and output encoding')
        
        return result