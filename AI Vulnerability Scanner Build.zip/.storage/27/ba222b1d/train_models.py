#!/usr/bin/env python3
"""
Training script for baseline ML models and RL agents.
Can be run standalone or called from the API.
"""

import asyncio
import argparse
import sys
import os
from loguru import logger

# Add the backend directory to Python path
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

from comprehensive_scanner.scanner import VulnerabilityScanner
from config import settings

async def train_baseline_models(dataset_path: str, model_dir: str):
    """Train all baseline ML models."""
    logger.info("Starting baseline model training...")
    
    scanner = VulnerabilityScanner(dataset_path, model_dir)
    await scanner.initialize_models()
    
    results = await scanner.train_baseline_models()
    
    logger.info("Baseline model training completed!")
    logger.info(f"Results: {results}")
    
    return results

async def train_rl_agents(dataset_path: str, model_dir: str, timesteps: int = 10000):
    """Train RL agents."""
    logger.info(f"Starting RL agent training with {timesteps} timesteps...")
    
    scanner = VulnerabilityScanner(dataset_path, model_dir)
    await scanner.initialize_models()
    
    results = await scanner.train_rl_agents(timesteps)
    
    logger.info("RL agent training completed!")
    logger.info(f"Results: {results}")
    
    return results

async def main():
    """Main training function."""
    parser = argparse.ArgumentParser(description="Train vulnerability scanner models")
    parser.add_argument("--dataset", required=True, help="Path to dataset CSV file")
    parser.add_argument("--model-dir", default="ai_models", help="Directory to save models")
    parser.add_argument("--type", choices=["baseline", "rl", "all"], default="all", 
                       help="Type of models to train")
    parser.add_argument("--timesteps", type=int, default=10000, 
                       help="Number of timesteps for RL training")
    
    args = parser.parse_args()
    
    # Configure logging
    logger.add("training.log", rotation="10 MB", level="INFO")
    
    if not os.path.exists(args.dataset):
        logger.error(f"Dataset file not found: {args.dataset}")
        return
    
    os.makedirs(args.model_dir, exist_ok=True)
    
    try:
        if args.type in ["baseline", "all"]:
            await train_baseline_models(args.dataset, args.model_dir)
        
        if args.type in ["rl", "all"]:
            await train_rl_agents(args.dataset, args.model_dir, args.timesteps)
        
        logger.info("All training completed successfully!")
        
    except Exception as e:
        logger.error(f"Training failed: {e}")
        raise

if __name__ == "__main__":
    asyncio.run(main())