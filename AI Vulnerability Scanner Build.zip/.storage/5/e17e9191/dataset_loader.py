import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import LabelEncoder, StandardScaler
from sklearn.feature_extraction.text import TfidfVectorizer
from typing import Tuple, Dict, Any, Optional
import re
import urllib.parse
from loguru import logger

class CSICDatasetLoader:
    """
    Loads and preprocesses the CSIC 2010 dataset for vulnerability detection.
    """
    
    def __init__(self, dataset_path: str):
        self.dataset_path = dataset_path
        self.label_encoder = LabelEncoder()
        self.scaler = StandardScaler()
        self.tfidf_vectorizer = TfidfVectorizer(max_features=1000, stop_words='english')
        self.vulnerability_types = {
            0: 'normal',
            1: 'sqli',
            2: 'xss', 
            3: 'csrf',
            4: 'traversal',
            5: 'buffer_overflow',
            6: 'format_string',
            7: 'ldap_injection',
            8: 'xpath_injection',
            9: 'code_injection'
        }
        
    def load_raw_data(self) -> pd.DataFrame:
        """Load raw CSV data."""
        try:
            # Read the CSV with proper handling of the format
            df = pd.read_csv(self.dataset_path, sep='|', header=0, low_memory=False)
            logger.info(f"Loaded dataset with {len(df)} rows and {len(df.columns)} columns")
            return df
        except Exception as e:
            logger.error(f"Error loading dataset: {e}")
            raise
    
    def extract_http_features(self, df: pd.DataFrame) -> pd.DataFrame:
        """Extract meaningful features from HTTP requests."""
        features_df = pd.DataFrame()
        
        # Basic request features
        features_df['method'] = df['Method'].fillna('GET')
        features_df['has_content'] = (~df['content'].isna()).astype(int)
        features_df['content_length'] = df['lenght'].fillna(0)
        
        # Header features
        features_df['has_pragma'] = (~df['Pragma'].isna()).astype(int)
        features_df['has_cache_control'] = (~df['Cache-Control'].isna()).astype(int)
        features_df['connection_close'] = df['connection'].fillna('').str.contains('close').astype(int)
        
        # Content type features
        features_df['content_type_form'] = df['content-type'].fillna('').str.contains('form-urlencoded').astype(int)
        features_df['content_type_json'] = df['content-type'].fillna('').str.contains('json').astype(int)
        features_df['content_type_xml'] = df['content-type'].fillna('').str.contains('xml').astype(int)
        
        # Accept header features
        accept_header = df['Accept'].fillna('')
        features_df['accepts_html'] = accept_header.str.contains('html').astype(int)
        features_df['accepts_xml'] = accept_header.str.contains('xml').astype(int)
        features_df['accepts_json'] = accept_header.str.contains('json').astype(int)
        
        # Content analysis features
        content = df['content'].fillna('')
        features_df['content_has_script'] = content.str.contains('<script', case=False).astype(int)
        features_df['content_has_sql_keywords'] = content.str.contains(
            r'(select|union|insert|update|delete|drop|create|alter)', case=False
        ).astype(int)
        features_df['content_has_special_chars'] = content.str.contains(r'[<>"\';]').astype(int)
        features_df['content_has_encoded_chars'] = content.str.contains(r'%[0-9a-fA-F]{2}').astype(int)
        features_df['content_suspicious_patterns'] = content.str.contains(
            r'(javascript:|vbscript:|onload|onerror|alert\(|eval\()', case=False
        ).astype(int)
        
        # URL/Parameter features
        features_df['has_parameters'] = content.str.contains('[&=]').astype(int)
        features_df['parameter_count'] = content.str.count('&') + content.str.contains('=').astype(int)
        
        # Statistical features
        features_df['content_length_actual'] = content.str.len()
        features_df['unique_char_ratio'] = content.apply(lambda x: len(set(x)) / max(len(x), 1))
        features_df['digit_ratio'] = content.str.count(r'\d') / content.str.len().replace(0, 1)
        features_df['special_char_ratio'] = content.str.count(r'[^a-zA-Z0-9\s]') / content.str.len().replace(0, 1)
        
        # Encoding method features
        encoding = df['Accept-encoding'].fillna('')
        features_df['accepts_gzip'] = encoding.str.contains('gzip').astype(int)
        features_df['accepts_deflate'] = encoding.str.contains('deflate').astype(int)
        
        # Fill NaN values
        features_df = features_df.fillna(0)
        
        logger.info(f"Extracted {len(features_df.columns)} features from HTTP requests")
        return features_df
    
    def encode_labels(self, df: pd.DataFrame) -> Tuple[np.ndarray, np.ndarray]:
        """
        Encode labels for binary and multi-class classification.
        Returns: (binary_labels, multiclass_labels)
        """
        # Binary classification: normal (0) vs anomalous (1)
        binary_labels = df['classification'].values
        
        # For multi-class, we'll simulate different attack types based on content patterns
        multiclass_labels = np.zeros(len(df))
        content = df['content'].fillna('')
        
        for idx, (_, row) in enumerate(df.iterrows()):
            if row['classification'] == 0:
                multiclass_labels[idx] = 0  # normal
            else:
                # Classify based on content patterns
                content_str = str(row['content']).lower()
                if any(keyword in content_str for keyword in ['select', 'union', 'insert', 'drop', 'delete']):
                    multiclass_labels[idx] = 1  # sqli
                elif any(keyword in content_str for keyword in ['<script', 'javascript:', 'alert(', 'onerror']):
                    multiclass_labels[idx] = 2  # xss
                elif 'csrf' in content_str or 'token' in content_str:
                    multiclass_labels[idx] = 3  # csrf
                elif any(keyword in content_str for keyword in ['../', '..\\', 'etc/passwd']):
                    multiclass_labels[idx] = 4  # traversal
                elif any(keyword in content_str for keyword in ['%n', '%s', '%x']):
                    multiclass_labels[idx] = 6  # format_string
                else:
                    multiclass_labels[idx] = 1  # default to sqli for anomalous
        
        logger.info(f"Encoded labels - Binary: {np.unique(binary_labels, return_counts=True)}")
        logger.info(f"Encoded labels - Multi-class: {np.unique(multiclass_labels, return_counts=True)}")
        
        return binary_labels.astype(int), multiclass_labels.astype(int)
    
    def preprocess_data(self, test_size: float = 0.2, random_state: int = 42) -> Dict[str, Any]:
        """
        Complete preprocessing pipeline.
        Returns dictionary with train/test splits and preprocessors.
        """
        # Load raw data
        df = self.load_raw_data()
        
        # Extract features
        features_df = self.extract_http_features(df)
        
        # Encode labels
        binary_labels, multiclass_labels = self.encode_labels(df)
        
        # Prepare feature matrix
        X = features_df.values
        
        # Scale features
        X_scaled = self.scaler.fit_transform(X)
        
        # Train/test split for binary classification
        X_train_bin, X_test_bin, y_train_bin, y_test_bin = train_test_split(
            X_scaled, binary_labels, test_size=test_size, random_state=random_state, stratify=binary_labels
        )
        
        # Train/test split for multi-class classification
        X_train_multi, X_test_multi, y_train_multi, y_test_multi = train_test_split(
            X_scaled, multiclass_labels, test_size=test_size, random_state=random_state, stratify=multiclass_labels
        )
        
        # Prepare text features for content analysis
        content_text = df['content'].fillna('').astype(str)
        content_tfidf = self.tfidf_vectorizer.fit_transform(content_text)
        
        X_train_text, X_test_text, _, _ = train_test_split(
            content_tfidf.toarray(), binary_labels, test_size=test_size, random_state=random_state, stratify=binary_labels
        )
        
        result = {
            'binary_classification': {
                'X_train': X_train_bin,
                'X_test': X_test_bin,
                'y_train': y_train_bin,
                'y_test': y_test_bin
            },
            'multiclass_classification': {
                'X_train': X_train_multi,
                'X_test': X_test_multi,
                'y_train': y_train_multi,
                'y_test': y_test_multi
            },
            'text_features': {
                'X_train': X_train_text,
                'X_test': X_test_text
            },
            'preprocessors': {
                'scaler': self.scaler,
                'tfidf_vectorizer': self.tfidf_vectorizer,
                'label_encoder': self.label_encoder
            },
            'feature_names': features_df.columns.tolist(),
            'vulnerability_types': self.vulnerability_types,
            'raw_data': df
        }
        
        logger.info("Data preprocessing completed successfully")
        return result

def load_and_preprocess_dataset(dataset_path: str) -> Dict[str, Any]:
    """Convenience function to load and preprocess the dataset."""
    loader = CSICDatasetLoader(dataset_path)
    return loader.preprocess_data()