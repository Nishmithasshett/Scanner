import asyncio
import uuid
from typing import Dict, Any, List, Optional
import numpy as np
from loguru import logger
import time
from datetime import datetime
import json

from ..ai_models.baseline_models import BaselineModels
from ..ai_models.rl_agents import RLTrainer
from ..attack_simulation.rl_environment import VulnerabilityScannersEnv, AttackSimulator
from ..data_processing.dataset_loader import CSICDatasetLoader

class VulnerabilityScanner:
    """
    Comprehensive vulnerability scanner that orchestrates ML models and RL agents.
    """
    
    def __init__(self, dataset_path: str, model_dir: str = "ai_models"):
        self.dataset_path = dataset_path
        self.model_dir = model_dir
        
        # Initialize components
        self.dataset_loader = CSICDatasetLoader(dataset_path)
        self.baseline_models = BaselineModels(model_dir)
        self.attack_simulator = AttackSimulator()
        
        # Load preprocessed data
        self.data = None
        self.rl_env = None
        self.rl_trainer = None
        
        # Scan results storage
        self.scan_results = {}
        
        # Vulnerability knowledge base
        self.vulnerability_kb = self._initialize_vulnerability_kb()
        
        logger.info("VulnerabilityScanner initialized")
    
    def _initialize_vulnerability_kb(self) -> Dict[str, Dict[str, Any]]:
        """Initialize vulnerability knowledge base with remediation advice."""
        return {
            'sqli': {
                'name': 'SQL Injection',
                'severity': 'High',
                'description': 'Malicious SQL code injection into application queries',
                'remediation': [
                    'Use parameterized queries/prepared statements',
                    'Implement input validation and sanitization',
                    'Use stored procedures with proper parameter handling',
                    'Apply principle of least privilege to database accounts',
                    'Enable SQL query logging and monitoring'
                ],
                'cwe': 'CWE-89',
                'owasp': 'A03:2021 – Injection'
            },
            'xss': {
                'name': 'Cross-Site Scripting',
                'severity': 'Medium',
                'description': 'Injection of malicious scripts into web pages',
                'remediation': [
                    'Implement proper output encoding/escaping',
                    'Use Content Security Policy (CSP)',
                    'Validate and sanitize all user inputs',
                    'Use secure coding frameworks',
                    'Implement HTTPOnly and Secure cookie flags'
                ],
                'cwe': 'CWE-79',
                'owasp': 'A03:2021 – Injection'
            },
            'csrf': {
                'name': 'Cross-Site Request Forgery',
                'severity': 'Medium',
                'description': 'Unauthorized commands transmitted from a user that the web application trusts',
                'remediation': [
                    'Implement CSRF tokens',
                    'Use SameSite cookie attribute',
                    'Verify HTTP Referer header',
                    'Implement proper session management',
                    'Use double-submit cookie pattern'
                ],
                'cwe': 'CWE-352',
                'owasp': 'A01:2021 – Broken Access Control'
            },
            'traversal': {
                'name': 'Path Traversal',
                'severity': 'High',
                'description': 'Access to files and directories outside the web root folder',
                'remediation': [
                    'Implement proper input validation',
                    'Use whitelist of allowed file paths',
                    'Avoid user input in file system calls',
                    'Use chroot jails or similar containment',
                    'Implement proper access controls'
                ],
                'cwe': 'CWE-22',
                'owasp': 'A01:2021 – Broken Access Control'
            }
        }
    
    async def initialize_models(self) -> Dict[str, Any]:
        """Initialize and load all models."""
        logger.info("Initializing models...")
        
        # Load and preprocess dataset
        self.data = self.dataset_loader.preprocess_data()
        
        # Initialize RL environment
        self.rl_env = VulnerabilityScannersEnv(
            self.data['binary_classification']['X_train'],
            self.data['binary_classification']['y_train'],
            self.data['vulnerability_types']
        )
        
        # Initialize RL trainer
        self.rl_trainer = RLTrainer(self.rl_env, self.model_dir)
        
        logger.info("Models initialized successfully")
        return {
            'status': 'success',
            'dataset_samples': len(self.data['raw_data']),
            'feature_count': len(self.data['feature_names']),
            'vulnerability_types': self.data['vulnerability_types']
        }
    
    async def train_baseline_models(self) -> Dict[str, Any]:
        """Train all baseline ML models."""
        if self.data is None:
            await self.initialize_models()
        
        logger.info("Training baseline models...")
        
        # Train sklearn models
        sklearn_results = self.baseline_models.train_sklearn_models(
            self.data['binary_classification']['X_train'],
            self.data['binary_classification']['y_train'],
            self.data['binary_classification']['X_test'],
            self.data['binary_classification']['y_test']
        )
        
        # Train neural network
        nn_results = self.baseline_models.train_neural_network(
            self.data['binary_classification']['X_train'],
            self.data['binary_classification']['y_train'],
            self.data['binary_classification']['X_test'],
            self.data['binary_classification']['y_test']
        )
        
        # Combine results
        all_results = {**sklearn_results, **nn_results}
        
        # Get model comparison
        comparison = self.baseline_models.compare_models()
        
        logger.info("Baseline model training completed")
        return {
            'training_results': all_results,
            'model_comparison': comparison.to_dict() if not comparison.empty else {},
            'best_model': self.baseline_models.get_best_model()[0] if all_results else None
        }
    
    async def train_rl_agents(self, timesteps: int = 10000) -> Dict[str, Any]:
        """Train RL agents."""
        if self.rl_trainer is None:
            await self.initialize_models()
        
        logger.info("Training RL agents...")
        
        # Train DQN
        dqn_results = self.rl_trainer.train_dqn(timesteps)
        
        # Train PPO
        ppo_results = self.rl_trainer.train_ppo(timesteps)
        
        # Compare agents
        comparison = self.rl_trainer.compare_agents()
        
        logger.info("RL agent training completed")
        return {
            'dqn_results': dqn_results,
            'ppo_results': ppo_results,
            'agent_comparison': comparison
        }
    
    async def scan_url(self, url: str, scan_options: Dict[str, Any] = None) -> str:
        """
        Initiate a comprehensive vulnerability scan for a URL.
        Returns scan_id for tracking progress.
        """
        scan_id = str(uuid.uuid4())
        scan_options = scan_options or {}
        
        logger.info(f"Starting scan for URL: {url} with scan_id: {scan_id}")
        
        # Initialize scan result
        self.scan_results[scan_id] = {
            'scan_id': scan_id,
            'url': url,
            'status': 'running',
            'start_time': datetime.now().isoformat(),
            'progress': 0,
            'vulnerabilities': [],
            'risk_score': 0,
            'scan_options': scan_options
        }
        
        # Start scan in background
        asyncio.create_task(self._perform_scan(scan_id, url, scan_options))
        
        return scan_id
    
    async def _perform_scan(self, scan_id: str, url: str, scan_options: Dict[str, Any]):
        """Perform the actual vulnerability scan."""
        try:
            # Simulate HTTP request analysis
            await self._update_scan_progress(scan_id, 10, "Analyzing HTTP requests...")
            
            # Generate synthetic request features for demonstration
            synthetic_features = self._generate_synthetic_features(url)
            
            # Run baseline model predictions
            await self._update_scan_progress(scan_id, 30, "Running ML-based detection...")
            ml_results = await self._run_ml_detection(synthetic_features)
            
            # Run RL agent analysis
            await self._update_scan_progress(scan_id, 60, "Running RL agent analysis...")
            rl_results = await self._run_rl_analysis(synthetic_features)
            
            # Combine results and generate report
            await self._update_scan_progress(scan_id, 80, "Generating vulnerability report...")
            vulnerabilities = self._combine_scan_results(ml_results, rl_results)
            
            # Calculate risk score
            risk_score = self._calculate_risk_score(vulnerabilities)
            
            # Update final results
            await self._update_scan_progress(scan_id, 100, "Scan completed")
            self.scan_results[scan_id].update({
                'status': 'completed',
                'end_time': datetime.now().isoformat(),
                'vulnerabilities': vulnerabilities,
                'risk_score': risk_score,
                'ml_results': ml_results,
                'rl_results': rl_results
            })
            
            logger.info(f"Scan {scan_id} completed successfully")
            
        except Exception as e:
            logger.error(f"Error in scan {scan_id}: {e}")
            self.scan_results[scan_id].update({
                'status': 'failed',
                'error': str(e),
                'end_time': datetime.now().isoformat()
            })
    
    def _generate_synthetic_features(self, url: str) -> np.ndarray:
        """Generate synthetic features for demonstration purposes."""
        # In a real implementation, this would extract features from actual HTTP requests
        np.random.seed(hash(url) % 2**32)
        features = np.random.random(20)  # 20 features matching our dataset
        
        # Add some realistic patterns based on URL
        if 'admin' in url.lower():
            features[0] = 0.8  # Higher suspicion
        if 'script' in url.lower():
            features[5] = 0.9  # XSS indicator
        if 'select' in url.lower() or 'union' in url.lower():
            features[6] = 0.9  # SQL injection indicator
        
        return features
    
    async def _run_ml_detection(self, features: np.ndarray) -> Dict[str, Any]:
        """Run ML-based vulnerability detection."""
        if not self.baseline_models.model_performance:
            # If models aren't trained, return mock results
            return {
                'predictions': {'normal': 0.3, 'anomalous': 0.7},
                'confidence': 0.85,
                'detected_vulnerabilities': ['sqli', 'xss']
            }
        
        try:
            best_model_name, _ = self.baseline_models.get_best_model()
            prediction_proba = self.baseline_models.predict_proba(best_model_name, features.reshape(1, -1))[0]
            prediction = self.baseline_models.predict(best_model_name, features.reshape(1, -1))[0]
            
            detected_vulns = []
            if prediction == 1:  # Anomalous
                # Simple heuristic based on feature values
                if features[6] > 0.7:
                    detected_vulns.append('sqli')
                if features[5] > 0.7:
                    detected_vulns.append('xss')
                if features[2] > 0.7:
                    detected_vulns.append('csrf')
            
            return {
                'model_used': best_model_name,
                'prediction': int(prediction),
                'confidence': float(prediction_proba),
                'detected_vulnerabilities': detected_vulns
            }
        except Exception as e:
            logger.error(f"Error in ML detection: {e}")
            return {
                'error': str(e),
                'detected_vulnerabilities': []
            }
    
    async def _run_rl_analysis(self, features: np.ndarray) -> Dict[str, Any]:
        """Run RL agent analysis."""
        if self.rl_trainer is None:
            return {
                'actions_taken': ['comprehensive_scan'],
                'confidence': 0.75,
                'detected_vulnerabilities': ['sqli']
            }
        
        try:
            # Get best RL agent
            best_agent = self.rl_trainer.get_best_agent()
            
            # Simulate RL agent decision making
            state = np.concatenate([features, np.zeros(5)])  # Add progress features
            action = best_agent.predict(state)
            
            # Simulate action results
            action_names = {
                0: 'sqli_probe', 1: 'xss_payload', 2: 'csrf_check',
                3: 'path_traversal', 4: 'buffer_overflow_test',
                5: 'format_string_test', 6: 'ldap_injection',
                7: 'xpath_injection', 8: 'code_injection',
                9: 'comprehensive_scan'
            }
            
            action_name = action_names.get(action, 'unknown')
            scan_result = self.attack_simulator.simulate_scan_action(action, features)
            
            return {
                'agent_used': 'best_rl_agent',
                'action_taken': action_name,
                'scan_result': scan_result,
                'detected_vulnerabilities': scan_result.get('detected_vulnerabilities', [])
            }
        except Exception as e:
            logger.error(f"Error in RL analysis: {e}")
            return {
                'error': str(e),
                'detected_vulnerabilities': []
            }
    
    def _combine_scan_results(self, ml_results: Dict[str, Any], rl_results: Dict[str, Any]) -> List[Dict[str, Any]]:
        """Combine ML and RL scan results into final vulnerability list."""
        vulnerabilities = []
        
        # Get detected vulnerabilities from both methods
        ml_vulns = set(ml_results.get('detected_vulnerabilities', []))
        rl_vulns = set(rl_results.get('detected_vulnerabilities', []))
        
        # Combine unique vulnerabilities
        all_vulns = ml_vulns.union(rl_vulns)
        
        for vuln_type in all_vulns:
            if vuln_type in self.vulnerability_kb:
                vuln_info = self.vulnerability_kb[vuln_type].copy()
                vuln_info.update({
                    'id': str(uuid.uuid4()),
                    'detected_by': [],
                    'confidence': 0.0
                })
                
                # Track detection methods and confidence
                if vuln_type in ml_vulns:
                    vuln_info['detected_by'].append('ML')
                    vuln_info['confidence'] += ml_results.get('confidence', 0.5)
                
                if vuln_type in rl_vulns:
                    vuln_info['detected_by'].append('RL')
                    vuln_info['confidence'] += 0.7  # Default RL confidence
                
                # Average confidence if detected by both
                if len(vuln_info['detected_by']) > 1:
                    vuln_info['confidence'] /= len(vuln_info['detected_by'])
                
                vulnerabilities.append(vuln_info)
        
        return vulnerabilities
    
    def _calculate_risk_score(self, vulnerabilities: List[Dict[str, Any]]) -> float:
        """Calculate overall risk score based on detected vulnerabilities."""
        if not vulnerabilities:
            return 0.0
        
        severity_weights = {
            'Low': 1.0,
            'Medium': 2.5,
            'High': 4.0,
            'Critical': 5.0
        }
        
        total_score = 0.0
        for vuln in vulnerabilities:
            severity = vuln.get('severity', 'Medium')
            confidence = vuln.get('confidence', 0.5)
            weight = severity_weights.get(severity, 2.5)
            total_score += weight * confidence
        
        # Normalize to 0-100 scale
        max_possible_score = len(vulnerabilities) * 5.0
        normalized_score = min((total_score / max_possible_score) * 100, 100)
        
        return round(normalized_score, 2)
    
    async def _update_scan_progress(self, scan_id: str, progress: int, message: str):
        """Update scan progress."""
        if scan_id in self.scan_results:
            self.scan_results[scan_id]['progress'] = progress
            self.scan_results[scan_id]['current_task'] = message
            logger.info(f"Scan {scan_id}: {progress}% - {message}")
    
    def get_scan_results(self, scan_id: str) -> Optional[Dict[str, Any]]:
        """Get scan results by scan_id."""
        return self.scan_results.get(scan_id)
    
    def get_vulnerability_recommendations(self, vuln_id: str) -> Dict[str, Any]:
        """Get detailed remediation recommendations for a vulnerability."""
        # Find vulnerability in scan results
        for scan_result in self.scan_results.values():
            for vuln in scan_result.get('vulnerabilities', []):
                if vuln.get('id') == vuln_id:
                    # Get base recommendations from knowledge base
                    vuln_type = None
                    for vtype, vinfo in self.vulnerability_kb.items():
                        if vinfo['name'] == vuln['name']:
                            vuln_type = vtype
                            break
                    
                    if vuln_type:
                        recommendations = self.vulnerability_kb[vuln_type]['remediation'].copy()
                        
                        # Add ML-assisted recommendations
                        ml_recommendations = self._get_ml_recommendations(vuln_type, vuln)
                        
                        return {
                            'vulnerability_id': vuln_id,
                            'vulnerability_type': vuln_type,
                            'severity': vuln['severity'],
                            'basic_remediation': recommendations,
                            'ml_assisted_recommendations': ml_recommendations,
                            'priority': self._calculate_remediation_priority(vuln),
                            'estimated_effort': self._estimate_remediation_effort(vuln_type),
                            'testing_recommendations': self._get_testing_recommendations(vuln_type)
                        }
        
        return {'error': 'Vulnerability not found'}
    
    def _get_ml_recommendations(self, vuln_type: str, vuln: Dict[str, Any]) -> List[str]:
        """Generate ML-assisted remediation recommendations."""
        confidence = vuln.get('confidence', 0.5)
        detected_by = vuln.get('detected_by', [])
        
        recommendations = []
        
        if confidence > 0.8:
            recommendations.append("High confidence detection - prioritize immediate remediation")
        
        if 'RL' in detected_by and 'ML' in detected_by:
            recommendations.append("Confirmed by multiple detection methods - high priority fix")
        
        # Vuln-specific ML recommendations
        if vuln_type == 'sqli':
            recommendations.extend([
                "Consider implementing a Web Application Firewall (WAF)",
                "Audit all database queries for parameterization",
                "Implement database activity monitoring"
            ])
        elif vuln_type == 'xss':
            recommendations.extend([
                "Implement Content Security Policy (CSP) headers",
                "Use template engines with auto-escaping",
                "Consider client-side input validation frameworks"
            ])
        
        return recommendations
    
    def _calculate_remediation_priority(self, vuln: Dict[str, Any]) -> str:
        """Calculate remediation priority based on vulnerability characteristics."""
        severity = vuln.get('severity', 'Medium')
        confidence = vuln.get('confidence', 0.5)
        
        if severity == 'Critical' or (severity == 'High' and confidence > 0.8):
            return 'Immediate'
        elif severity == 'High' or (severity == 'Medium' and confidence > 0.8):
            return 'High'
        elif severity == 'Medium':
            return 'Medium'
        else:
            return 'Low'
    
    def _estimate_remediation_effort(self, vuln_type: str) -> str:
        """Estimate effort required for remediation."""
        effort_map = {
            'sqli': 'Medium - Requires code review and query refactoring',
            'xss': 'Low - Implement output encoding and CSP',
            'csrf': 'Low - Add CSRF tokens to forms',
            'traversal': 'Medium - Implement input validation and access controls'
        }
        return effort_map.get(vuln_type, 'Medium - Requires security review')
    
    def _get_testing_recommendations(self, vuln_type: str) -> List[str]:
        """Get testing recommendations for vulnerability type."""
        testing_map = {
            'sqli': [
                "Use automated SQL injection testing tools",
                "Perform manual testing with various SQL payloads",
                "Test with different database error conditions"
            ],
            'xss': [
                "Test with various XSS payloads",
                "Verify CSP implementation",
                "Test in different browsers and contexts"
            ],
            'csrf': [
                "Test CSRF token validation",
                "Verify SameSite cookie attributes",
                "Test with different HTTP methods"
            ],
            'traversal': [
                "Test with various path traversal payloads",
                "Verify access controls on file system",
                "Test with encoded path sequences"
            ]
        }
        return testing_map.get(vuln_type, ["Perform security-focused testing"])

# Singleton instance for global access
scanner_instance = None

def get_scanner_instance(dataset_path: str = None, model_dir: str = "ai_models") -> VulnerabilityScanner:
    """Get or create scanner instance."""
    global scanner_instance
    if scanner_instance is None and dataset_path:
        scanner_instance = VulnerabilityScanner(dataset_path, model_dir)
    return scanner_instance