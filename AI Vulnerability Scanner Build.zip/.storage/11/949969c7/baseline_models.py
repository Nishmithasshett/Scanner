import numpy as np
import pandas as pd
from sklearn.ensemble import RandomForestClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.svm import SVC
from sklearn.neural_network import MLPClassifier
from sklearn.metrics import classification_report, confusion_matrix, roc_auc_score
from sklearn.model_selection import cross_val_score, GridSearchCV
import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import DataLoader, TensorDataset
import joblib
import os
from typing import Dict, Any, Tuple, List
from loguru import logger

class SimpleNeuralNetwork(nn.Module):
    """Simple neural network for vulnerability detection."""
    
    def __init__(self, input_dim: int, hidden_dims: List[int], output_dim: int, dropout: float = 0.2):
        super().__init__()
        
        layers = []
        prev_dim = input_dim
        
        for hidden_dim in hidden_dims:
            layers.extend([
                nn.Linear(prev_dim, hidden_dim),
                nn.ReLU(),
                nn.Dropout(dropout)
            ])
            prev_dim = hidden_dim
        
        layers.append(nn.Linear(prev_dim, output_dim))
        
        if output_dim > 1:
            layers.append(nn.Softmax(dim=1))
        else:
            layers.append(nn.Sigmoid())
        
        self.network = nn.Sequential(*layers)
    
    def forward(self, x):
        return self.network(x)

class BaselineModels:
    """Collection of baseline machine learning models for vulnerability detection."""
    
    def __init__(self, model_dir: str = "ai_models"):
        self.model_dir = model_dir
        os.makedirs(model_dir, exist_ok=True)
        
        self.models = {}
        self.model_performance = {}
        
        # Initialize models
        self._initialize_models()
    
    def _initialize_models(self):
        """Initialize all baseline models."""
        self.models = {
            'logistic_regression': LogisticRegression(
                random_state=42, 
                max_iter=1000,
                class_weight='balanced'
            ),
            'random_forest': RandomForestClassifier(
                n_estimators=100,
                random_state=42,
                class_weight='balanced',
                n_jobs=-1
            ),
            'svm': SVC(
                kernel='rbf',
                random_state=42,
                class_weight='balanced',
                probability=True
            ),
            'mlp': MLPClassifier(
                hidden_layer_sizes=(100, 50),
                random_state=42,
                max_iter=500,
                early_stopping=True,
                validation_fraction=0.1
            )
        }
    
    def train_sklearn_models(self, X_train: np.ndarray, y_train: np.ndarray, 
                           X_test: np.ndarray, y_test: np.ndarray) -> Dict[str, Any]:
        """Train all sklearn-based models."""
        results = {}
        
        for model_name, model in self.models.items():
            logger.info(f"Training {model_name}...")
            
            try:
                # Train model
                model.fit(X_train, y_train)
                
                # Make predictions
                y_pred = model.predict(X_test)
                y_pred_proba = model.predict_proba(X_test)[:, 1] if hasattr(model, 'predict_proba') else None
                
                # Calculate metrics
                metrics = self._calculate_metrics(y_test, y_pred, y_pred_proba)
                
                # Cross-validation score
                cv_scores = cross_val_score(model, X_train, y_train, cv=5, scoring='f1')
                metrics['cv_f1_mean'] = cv_scores.mean()
                metrics['cv_f1_std'] = cv_scores.std()
                
                results[model_name] = metrics
                self.model_performance[model_name] = metrics
                
                # Save model
                model_path = os.path.join(self.model_dir, f"{model_name}.joblib")
                joblib.dump(model, model_path)
                logger.info(f"Saved {model_name} to {model_path}")
                
            except Exception as e:
                logger.error(f"Error training {model_name}: {e}")
                results[model_name] = {'error': str(e)}
        
        return results
    
    def train_neural_network(self, X_train: np.ndarray, y_train: np.ndarray,
                           X_test: np.ndarray, y_test: np.ndarray,
                           epochs: int = 100, batch_size: int = 32) -> Dict[str, Any]:
        """Train PyTorch neural network."""
        logger.info("Training neural network...")
        
        # Prepare data
        X_train_tensor = torch.FloatTensor(X_train)
        y_train_tensor = torch.FloatTensor(y_train).unsqueeze(1)
        X_test_tensor = torch.FloatTensor(X_test)
        y_test_tensor = torch.FloatTensor(y_test).unsqueeze(1)
        
        train_dataset = TensorDataset(X_train_tensor, y_train_tensor)
        train_loader = DataLoader(train_dataset, batch_size=batch_size, shuffle=True)
        
        # Initialize model
        input_dim = X_train.shape[1]
        model = SimpleNeuralNetwork(input_dim, [128, 64, 32], 1)
        criterion = nn.BCELoss()
        optimizer = optim.Adam(model.parameters(), lr=0.001)
        
        # Training loop
        train_losses = []
        for epoch in range(epochs):
            model.train()
            epoch_loss = 0
            
            for batch_X, batch_y in train_loader:
                optimizer.zero_grad()
                outputs = model(batch_X)
                loss = criterion(outputs, batch_y)
                loss.backward()
                optimizer.step()
                epoch_loss += loss.item()
            
            avg_loss = epoch_loss / len(train_loader)
            train_losses.append(avg_loss)
            
            if epoch % 20 == 0:
                logger.info(f"Epoch {epoch}/{epochs}, Loss: {avg_loss:.4f}")
        
        # Evaluation
        model.eval()
        with torch.no_grad():
            y_pred_proba = model(X_test_tensor).squeeze().numpy()
            y_pred = (y_pred_proba > 0.5).astype(int)
        
        metrics = self._calculate_metrics(y_test, y_pred, y_pred_proba)
        metrics['training_losses'] = train_losses
        
        # Save model
        model_path = os.path.join(self.model_dir, "neural_network.pth")
        torch.save(model.state_dict(), model_path)
        logger.info(f"Saved neural network to {model_path}")
        
        self.model_performance['neural_network'] = metrics
        return {'neural_network': metrics}
    
    def _calculate_metrics(self, y_true: np.ndarray, y_pred: np.ndarray, 
                          y_pred_proba: np.ndarray = None) -> Dict[str, float]:
        """Calculate comprehensive metrics for model evaluation."""
        from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score
        
        metrics = {
            'accuracy': accuracy_score(y_true, y_pred),
            'precision': precision_score(y_true, y_pred, average='weighted', zero_division=0),
            'recall': recall_score(y_true, y_pred, average='weighted', zero_division=0),
            'f1': f1_score(y_true, y_pred, average='weighted', zero_division=0)
        }
        
        if y_pred_proba is not None:
            try:
                metrics['auc_roc'] = roc_auc_score(y_true, y_pred_proba)
            except ValueError:
                metrics['auc_roc'] = 0.0
        
        return metrics
    
    def hyperparameter_tuning(self, X_train: np.ndarray, y_train: np.ndarray) -> Dict[str, Any]:
        """Perform hyperparameter tuning for selected models."""
        logger.info("Starting hyperparameter tuning...")
        
        param_grids = {
            'random_forest': {
                'n_estimators': [50, 100, 200],
                'max_depth': [None, 10, 20],
                'min_samples_split': [2, 5, 10]
            },
            'svm': {
                'C': [0.1, 1, 10],
                'gamma': ['scale', 'auto', 0.001, 0.01]
            },
            'logistic_regression': {
                'C': [0.1, 1, 10, 100],
                'penalty': ['l1', 'l2'],
                'solver': ['liblinear', 'saga']
            }
        }
        
        tuned_models = {}
        
        for model_name, param_grid in param_grids.items():
            if model_name in self.models:
                logger.info(f"Tuning {model_name}...")
                
                grid_search = GridSearchCV(
                    self.models[model_name],
                    param_grid,
                    cv=3,
                    scoring='f1',
                    n_jobs=-1,
                    verbose=0
                )
                
                grid_search.fit(X_train, y_train)
                
                tuned_models[model_name] = {
                    'best_params': grid_search.best_params_,
                    'best_score': grid_search.best_score_,
                    'model': grid_search.best_estimator_
                }
                
                # Save tuned model
                model_path = os.path.join(self.model_dir, f"{model_name}_tuned.joblib")
                joblib.dump(grid_search.best_estimator_, model_path)
        
        logger.info("Hyperparameter tuning completed")
        return tuned_models
    
    def compare_models(self) -> pd.DataFrame:
        """Compare performance of all trained models."""
        if not self.model_performance:
            logger.warning("No models have been trained yet")
            return pd.DataFrame()
        
        comparison_df = pd.DataFrame(self.model_performance).T
        comparison_df = comparison_df.sort_values('f1', ascending=False)
        
        logger.info("Model comparison:")
        logger.info(f"\n{comparison_df}")
        
        return comparison_df
    
    def get_best_model(self) -> Tuple[str, Any]:
        """Get the best performing model based on F1 score."""
        if not self.model_performance:
            raise ValueError("No models have been trained yet")
        
        best_model_name = max(self.model_performance.keys(), 
                            key=lambda k: self.model_performance[k].get('f1', 0))
        
        # Load the best model
        if best_model_name == 'neural_network':
            model_path = os.path.join(self.model_dir, "neural_network.pth")
            input_dim = 20  # This should match your feature dimension
            best_model = SimpleNeuralNetwork(input_dim, [128, 64, 32], 1)
            best_model.load_state_dict(torch.load(model_path))
        else:
            model_path = os.path.join(self.model_dir, f"{best_model_name}.joblib")
            best_model = joblib.load(model_path)
        
        logger.info(f"Best model: {best_model_name} with F1 score: {self.model_performance[best_model_name]['f1']:.4f}")
        
        return best_model_name, best_model
    
    def predict(self, model_name: str, X: np.ndarray) -> np.ndarray:
        """Make predictions using a specific model."""
        if model_name == 'neural_network':
            model_path = os.path.join(self.model_dir, "neural_network.pth")
            input_dim = X.shape[1]
            model = SimpleNeuralNetwork(input_dim, [128, 64, 32], 1)
            model.load_state_dict(torch.load(model_path))
            model.eval()
            
            with torch.no_grad():
                X_tensor = torch.FloatTensor(X)
                predictions = model(X_tensor).squeeze().numpy()
                return (predictions > 0.5).astype(int)
        else:
            model_path = os.path.join(self.model_dir, f"{model_name}.joblib")
            model = joblib.load(model_path)
            return model.predict(X)
    
    def predict_proba(self, model_name: str, X: np.ndarray) -> np.ndarray:
        """Get prediction probabilities from a specific model."""
        if model_name == 'neural_network':
            model_path = os.path.join(self.model_dir, "neural_network.pth")
            input_dim = X.shape[1]
            model = SimpleNeuralNetwork(input_dim, [128, 64, 32], 1)
            model.load_state_dict(torch.load(model_path))
            model.eval()
            
            with torch.no_grad():
                X_tensor = torch.FloatTensor(X)
                return model(X_tensor).squeeze().numpy()
        else:
            model_path = os.path.join(self.model_dir, f"{model_name}.joblib")
            model = joblib.load(model_path)
            if hasattr(model, 'predict_proba'):
                return model.predict_proba(X)[:, 1]
            else:
                return model.decision_function(X)

class ModelEnsemble:
    """Ensemble of multiple models for improved performance."""
    
    def __init__(self, models: Dict[str, Any], weights: Dict[str, float] = None):
        self.models = models
        self.weights = weights or {name: 1.0 for name in models.keys()}
        self.normalize_weights()
    
    def normalize_weights(self):
        """Normalize weights to sum to 1."""
        total_weight = sum(self.weights.values())
        self.weights = {name: weight / total_weight for name, weight in self.weights.items()}
    
    def predict_proba(self, X: np.ndarray) -> np.ndarray:
        """Get ensemble prediction probabilities."""
        predictions = []
        
        for model_name, model in self.models.items():
            if hasattr(model, 'predict_proba'):
                pred_proba = model.predict_proba(X)[:, 1]
            elif hasattr(model, 'decision_function'):
                pred_proba = model.decision_function(X)
            else:
                pred_proba = model.predict(X)
            
            predictions.append(pred_proba * self.weights[model_name])
        
        return np.sum(predictions, axis=0)
    
    def predict(self, X: np.ndarray, threshold: float = 0.5) -> np.ndarray:
        """Get ensemble predictions."""
        proba = self.predict_proba(X)
        return (proba > threshold).astype(int)