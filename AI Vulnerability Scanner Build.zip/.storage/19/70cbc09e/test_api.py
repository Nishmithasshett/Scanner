import pytest
import asyncio
from fastapi.testclient import TestClient
from unittest.mock import Mock, patch
import json

from ..api.main import app
from ..comprehensive_scanner.scanner import VulnerabilityScanner

client = TestClient(app)

@pytest.fixture
def mock_scanner():
    """Create a mock scanner for testing."""
    scanner = Mock(spec=VulnerabilityScanner)
    scanner.scan_results = {}
    scanner.vulnerability_kb = {
        'sqli': {
            'name': 'SQL Injection',
            'severity': 'High',
            'description': 'Test description',
            'remediation': ['Test remediation']
        }
    }
    return scanner

def test_root_endpoint():
    """Test the root endpoint."""
    response = client.get("/")
    assert response.status_code == 200
    data = response.json()
    assert "message" in data
    assert "version" in data
    assert "endpoints" in data

def test_health_check():
    """Test the health check endpoint."""
    response = client.get("/health")
    assert response.status_code == 200
    data = response.json()
    assert data["status"] == "healthy"

@patch('backend.api.main.scanner')
def test_submit_scan(mock_scanner_instance, mock_scanner):
    """Test submitting a scan."""
    mock_scanner_instance = mock_scanner
    mock_scanner.scan_url.return_value = "test-scan-id"
    
    scan_data = {
        "url": "https://example.com",
        "scan_options": {}
    }
    
    response = client.post("/scan", json=scan_data)
    assert response.status_code == 200
    data = response.json()
    assert "scan_id" in data
    assert data["status"] == "submitted"

@patch('backend.api.main.scanner')
def test_get_scan_results(mock_scanner_instance, mock_scanner):
    """Test getting scan results."""
    mock_scanner_instance = mock_scanner
    mock_scanner.get_scan_results.return_value = {
        "scan_id": "test-id",
        "status": "completed",
        "vulnerabilities": []
    }
    
    response = client.get("/results/test-id")
    assert response.status_code == 200
    data = response.json()
    assert data["scan_id"] == "test-id"

@patch('backend.api.main.scanner')
def test_get_scan_results_not_found(mock_scanner_instance, mock_scanner):
    """Test getting scan results for non-existent scan."""
    mock_scanner_instance = mock_scanner
    mock_scanner.get_scan_results.return_value = None
    
    response = client.get("/results/non-existent")
    assert response.status_code == 404

@patch('backend.api.main.scanner')
def test_train_baseline_models(mock_scanner_instance, mock_scanner):
    """Test training baseline models."""
    mock_scanner_instance = mock_scanner
    mock_scanner.train_baseline_models.return_value = {
        "training_results": {"logistic_regression": {"f1": 0.85}},
        "model_comparison": {},
        "best_model": "logistic_regression"
    }
    
    training_data = {
        "model_type": "baseline",
        "parameters": {}
    }
    
    response = client.post("/train/baseline", json=training_data)
    assert response.status_code == 200
    data = response.json()
    assert data["status"] == "completed"
    assert "results" in data

def test_scanner_not_initialized():
    """Test endpoints when scanner is not initialized."""
    with patch('backend.api.main.scanner', None):
        response = client.post("/scan", json={"url": "https://example.com"})
        assert response.status_code == 503
        assert "Scanner not initialized" in response.json()["detail"]