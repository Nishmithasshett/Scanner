#!/usr/bin/env python3
"""
Demo script showing how to use the vulnerability scanner system.
"""

import asyncio
import sys
import os

# Add the backend directory to Python path
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

from comprehensive_scanner.scanner import VulnerabilityScanner
from data_processing.dataset_loader import CSICDatasetLoader

async def demo_scanner():
    """Demonstrate the vulnerability scanner functionality."""
    print("🔍 AI-Powered Vulnerability Scanner Demo")
    print("=" * 50)
    
    # Initialize scanner with the provided dataset
    dataset_path = "/workspace/uploads/database.csv"
    
    if not os.path.exists(dataset_path):
        print(f"❌ Dataset not found at {dataset_path}")
        return
    
    print(f"📊 Loading dataset from: {dataset_path}")
    scanner = VulnerabilityScanner(dataset_path)
    
    # Initialize models
    print("🤖 Initializing AI models...")
    init_result = await scanner.initialize_models()
    print(f"✅ Models initialized: {init_result['dataset_samples']} samples, {init_result['feature_count']} features")
    
    # Demonstrate URL scanning
    print("\n🎯 Starting vulnerability scan...")
    test_urls = [
        "https://example.com/admin",
        "https://test.com/search?q=<script>alert('xss')</script>",
        "https://vulnerable.com/login?id=' OR '1'='1"
    ]
    
    scan_results = []
    for url in test_urls:
        print(f"🔍 Scanning: {url}")
        scan_id = await scanner.scan_url(url)
        scan_results.append(scan_id)
        print(f"📋 Scan ID: {scan_id}")
    
    # Wait for scans to complete (simulate)
    await asyncio.sleep(2)
    
    # Display results
    print("\n📊 Scan Results:")
    print("-" * 30)
    
    for scan_id in scan_results:
        result = scanner.get_scan_results(scan_id)
        if result:
            print(f"\n🆔 Scan ID: {scan_id}")
            print(f"🌐 URL: {result['url']}")
            print(f"📈 Status: {result['status']}")
            print(f"⚠️  Risk Score: {result.get('risk_score', 0)}")
            
            vulnerabilities = result.get('vulnerabilities', [])
            if vulnerabilities:
                print(f"🚨 Vulnerabilities Found: {len(vulnerabilities)}")
                for vuln in vulnerabilities:
                    print(f"   • {vuln['name']} (Severity: {vuln['severity']}, Confidence: {vuln.get('confidence', 0):.2f})")
            else:
                print("✅ No vulnerabilities detected")
    
    print("\n🎉 Demo completed successfully!")

async def demo_training():
    """Demonstrate model training."""
    print("\n🎓 Model Training Demo")
    print("=" * 30)
    
    dataset_path = "/workspace/uploads/database.csv"
    scanner = VulnerabilityScanner(dataset_path)
    
    await scanner.initialize_models()
    
    print("🤖 Training baseline ML models...")
    try:
        baseline_results = await scanner.train_baseline_models()
        print("✅ Baseline models trained successfully!")
        
        if baseline_results.get('best_model'):
            print(f"🏆 Best model: {baseline_results['best_model']}")
    except Exception as e:
        print(f"⚠️  Baseline training demo (expected in limited environment): {e}")
    
    print("🧠 Training RL agents...")
    try:
        rl_results = await scanner.train_rl_agents(timesteps=1000)  # Small number for demo
        print("✅ RL agents trained successfully!")
    except Exception as e:
        print(f"⚠️  RL training demo (expected in limited environment): {e}")

if __name__ == "__main__":
    print("🚀 Starting Vulnerability Scanner Demo")
    asyncio.run(demo_scanner())
    asyncio.run(demo_training())