import pytest
import numpy as np
import pandas as pd
from unittest.mock import Mock, patch
import asyncio

from ..comprehensive_scanner.scanner import VulnerabilityScanner
from ..data_processing.dataset_loader import CSICDatasetLoader

@pytest.fixture
def mock_dataset():
    """Create mock dataset for testing."""
    return {
        'binary_classification': {
            'X_train': np.random.random((100, 20)),
            'X_test': np.random.random((20, 20)),
            'y_train': np.random.randint(0, 2, 100),
            'y_test': np.random.randint(0, 2, 20)
        },
        'multiclass_classification': {
            'X_train': np.random.random((100, 20)),
            'X_test': np.random.random((20, 20)),
            'y_train': np.random.randint(0, 5, 100),
            'y_test': np.random.randint(0, 5, 20)
        },
        'feature_names': [f'feature_{i}' for i in range(20)],
        'vulnerability_types': {0: 'normal', 1: 'sqli', 2: 'xss'},
        'raw_data': pd.DataFrame({'test': [1, 2, 3]})
    }

@pytest.fixture
def scanner(mock_dataset):
    """Create scanner instance with mocked data."""
    with patch.object(CSICDatasetLoader, 'preprocess_data', return_value=mock_dataset):
        scanner = VulnerabilityScanner("test_dataset.csv")
        return scanner

@pytest.mark.asyncio
async def test_scanner_initialization(scanner, mock_dataset):
    """Test scanner initialization."""
    result = await scanner.initialize_models()
    
    assert result['status'] == 'success'
    assert 'dataset_samples' in result
    assert 'feature_count' in result
    assert scanner.data is not None

@pytest.mark.asyncio
async def test_scan_url(scanner, mock_dataset):
    """Test URL scanning functionality."""
    await scanner.initialize_models()
    
    scan_id = await scanner.scan_url("https://example.com")
    
    assert scan_id is not None
    assert scan_id in scanner.scan_results
    assert scanner.scan_results[scan_id]['status'] == 'running'
    assert scanner.scan_results[scan_id]['url'] == "https://example.com"

def test_generate_synthetic_features(scanner):
    """Test synthetic feature generation."""
    features = scanner._generate_synthetic_features("https://example.com/admin")
    
    assert len(features) == 20
    assert features[0] == 0.8  # Admin indicator should be high

def test_calculate_risk_score(scanner):
    """Test risk score calculation."""
    vulnerabilities = [
        {'severity': 'High', 'confidence': 0.9},
        {'severity': 'Medium', 'confidence': 0.7}
    ]
    
    risk_score = scanner._calculate_risk_score(vulnerabilities)
    
    assert 0 <= risk_score <= 100
    assert risk_score > 0  # Should be positive with vulnerabilities

def test_vulnerability_recommendations(scanner):
    """Test vulnerability recommendation generation."""
    # Add a test vulnerability to scan results
    test_vuln_id = "test-vuln-123"
    scanner.scan_results["test-scan"] = {
        'vulnerabilities': [{
            'id': test_vuln_id,
            'name': 'SQL Injection',
            'severity': 'High',
            'confidence': 0.9,
            'detected_by': ['ML', 'RL']
        }]
    }
    
    recommendations = scanner.get_vulnerability_recommendations(test_vuln_id)
    
    assert 'vulnerability_id' in recommendations
    assert 'basic_remediation' in recommendations
    assert 'ml_assisted_recommendations' in recommendations
    assert recommendations['vulnerability_id'] == test_vuln_id

def test_combine_scan_results(scanner):
    """Test combining ML and RL scan results."""
    ml_results = {
        'detected_vulnerabilities': ['sqli', 'xss'],
        'confidence': 0.8
    }
    
    rl_results = {
        'detected_vulnerabilities': ['sqli'],
        'confidence': 0.7
    }
    
    vulnerabilities = scanner._combine_scan_results(ml_results, rl_results)
    
    assert len(vulnerabilities) >= 1
    # Should have both sqli and xss
    vuln_names = [v['name'] for v in vulnerabilities]
    assert 'SQL Injection' in vuln_names
    assert 'Cross-Site Scripting' in vuln_names

@pytest.mark.asyncio
async def test_train_baseline_models(scanner, mock_dataset):
    """Test baseline model training."""
    await scanner.initialize_models()
    
    with patch.object(scanner.baseline_models, 'train_sklearn_models') as mock_train_sklearn, \
         patch.object(scanner.baseline_models, 'train_neural_network') as mock_train_nn:
        
        mock_train_sklearn.return_value = {'logistic_regression': {'f1': 0.85}}
        mock_train_nn.return_value = {'neural_network': {'f1': 0.80}}
        
        results = await scanner.train_baseline_models()
        
        assert 'training_results' in results
        assert 'model_comparison' in results
        mock_train_sklearn.assert_called_once()
        mock_train_nn.assert_called_once()