import torch
import torch.nn as nn
import torch.optim as optim
import numpy as np
from collections import deque
import random
from typing import Dict, Any, Tuple, Optional
from stable_baselines3 import DQN, PPO
from stable_baselines3.common.env_util import make_vec_env
from stable_baselines3.common.callbacks import BaseCallback
from loguru import logger
import os

class DQNAgent:
    """Deep Q-Network agent for vulnerability scanning."""
    
    def __init__(self, state_dim: int, action_dim: int, lr: float = 0.001):
        self.state_dim = state_dim
        self.action_dim = action_dim
        self.lr = lr
        
        # Neural network
        self.q_network = self._build_network()
        self.target_network = self._build_network()
        self.optimizer = optim.Adam(self.q_network.parameters(), lr=lr)
        
        # Experience replay
        self.memory = deque(maxlen=10000)
        self.batch_size = 32
        
        # Exploration parameters
        self.epsilon = 1.0
        self.epsilon_min = 0.01
        self.epsilon_decay = 0.995
        
        # Training parameters
        self.gamma = 0.95
        self.target_update_freq = 100
        self.update_counter = 0
        
    def _build_network(self) -> nn.Module:
        """Build the Q-network."""
        return nn.Sequential(
            nn.Linear(self.state_dim, 128),
            nn.ReLU(),
            nn.Dropout(0.2),
            nn.Linear(128, 64),
            nn.ReLU(),
            nn.Dropout(0.2),
            nn.Linear(64, 32),
            nn.ReLU(),
            nn.Linear(32, self.action_dim)
        )
    
    def remember(self, state: np.ndarray, action: int, reward: float, 
                 next_state: np.ndarray, done: bool):
        """Store experience in replay buffer."""
        self.memory.append((state, action, reward, next_state, done))
    
    def act(self, state: np.ndarray, training: bool = True) -> int:
        """Choose action using epsilon-greedy policy."""
        if training and np.random.random() <= self.epsilon:
            return np.random.choice(self.action_dim)
        
        with torch.no_grad():
            state_tensor = torch.FloatTensor(state).unsqueeze(0)
            q_values = self.q_network(state_tensor)
            return q_values.argmax().item()
    
    def replay(self):
        """Train the network on a batch of experiences."""
        if len(self.memory) < self.batch_size:
            return
        
        batch = random.sample(self.memory, self.batch_size)
        states = torch.FloatTensor([e[0] for e in batch])
        actions = torch.LongTensor([e[1] for e in batch])
        rewards = torch.FloatTensor([e[2] for e in batch])
        next_states = torch.FloatTensor([e[3] for e in batch])
        dones = torch.BoolTensor([e[4] for e in batch])
        
        current_q_values = self.q_network(states).gather(1, actions.unsqueeze(1))
        next_q_values = self.target_network(next_states).max(1)[0].detach()
        target_q_values = rewards + (self.gamma * next_q_values * ~dones)
        
        loss = nn.MSELoss()(current_q_values.squeeze(), target_q_values)
        
        self.optimizer.zero_grad()
        loss.backward()
        self.optimizer.step()
        
        # Update target network
        self.update_counter += 1
        if self.update_counter % self.target_update_freq == 0:
            self.target_network.load_state_dict(self.q_network.state_dict())
        
        # Decay epsilon
        if self.epsilon > self.epsilon_min:
            self.epsilon *= self.epsilon_decay
    
    def save(self, filepath: str):
        """Save the model."""
        torch.save({
            'q_network': self.q_network.state_dict(),
            'target_network': self.target_network.state_dict(),
            'optimizer': self.optimizer.state_dict(),
            'epsilon': self.epsilon
        }, filepath)
    
    def load(self, filepath: str):
        """Load the model."""
        checkpoint = torch.load(filepath)
        self.q_network.load_state_dict(checkpoint['q_network'])
        self.target_network.load_state_dict(checkpoint['target_network'])
        self.optimizer.load_state_dict(checkpoint['optimizer'])
        self.epsilon = checkpoint['epsilon']

class PPOAgent:
    """PPO agent wrapper using Stable Baselines3."""
    
    def __init__(self, env, model_path: str = None):
        self.env = env
        self.model_path = model_path
        
        if model_path and os.path.exists(model_path):
            self.model = PPO.load(model_path, env=env)
            logger.info(f"Loaded PPO model from {model_path}")
        else:
            self.model = PPO(
                "MlpPolicy",
                env,
                learning_rate=0.0003,
                n_steps=2048,
                batch_size=64,
                n_epochs=10,
                gamma=0.99,
                gae_lambda=0.95,
                clip_range=0.2,
                verbose=1
            )
            logger.info("Created new PPO model")
    
    def train(self, total_timesteps: int = 10000):
        """Train the PPO agent."""
        callback = TrainingCallback()
        self.model.learn(total_timesteps=total_timesteps, callback=callback)
        logger.info(f"PPO training completed for {total_timesteps} timesteps")
    
    def predict(self, observation):
        """Predict action for given observation."""
        action, _ = self.model.predict(observation, deterministic=True)
        return action
    
    def save(self, filepath: str):
        """Save the model."""
        self.model.save(filepath)
        logger.info(f"PPO model saved to {filepath}")

class DQNAgentSB3:
    """DQN agent wrapper using Stable Baselines3."""
    
    def __init__(self, env, model_path: str = None):
        self.env = env
        self.model_path = model_path
        
        if model_path and os.path.exists(model_path):
            self.model = DQN.load(model_path, env=env)
            logger.info(f"Loaded DQN model from {model_path}")
        else:
            self.model = DQN(
                "MlpPolicy",
                env,
                learning_rate=0.0001,
                buffer_size=50000,
                learning_starts=1000,
                batch_size=32,
                tau=1.0,
                gamma=0.99,
                train_freq=4,
                gradient_steps=1,
                target_update_interval=1000,
                exploration_fraction=0.1,
                exploration_initial_eps=1.0,
                exploration_final_eps=0.05,
                verbose=1
            )
            logger.info("Created new DQN model")
    
    def train(self, total_timesteps: int = 10000):
        """Train the DQN agent."""
        callback = TrainingCallback()
        self.model.learn(total_timesteps=total_timesteps, callback=callback)
        logger.info(f"DQN training completed for {total_timesteps} timesteps")
    
    def predict(self, observation):
        """Predict action for given observation."""
        action, _ = self.model.predict(observation, deterministic=True)
        return action
    
    def save(self, filepath: str):
        """Save the model."""
        self.model.save(filepath)
        logger.info(f"DQN model saved to {filepath}")

class TrainingCallback(BaseCallback):
    """Callback for monitoring training progress."""
    
    def __init__(self, verbose=0):
        super().__init__(verbose)
        self.episode_rewards = []
        self.episode_lengths = []
    
    def _on_step(self) -> bool:
        # Log training metrics
        if len(self.locals.get('infos', [])) > 0:
            info = self.locals['infos'][0]
            if 'episode' in info:
                self.episode_rewards.append(info['episode']['r'])
                self.episode_lengths.append(info['episode']['l'])
                
                if len(self.episode_rewards) % 100 == 0:
                    mean_reward = np.mean(self.episode_rewards[-100:])
                    logger.info(f"Mean reward (last 100 episodes): {mean_reward:.2f}")
        
        return True

class RLTrainer:
    """Orchestrates RL training for vulnerability scanning."""
    
    def __init__(self, env, model_dir: str = "ai_models"):
        self.env = env
        self.model_dir = model_dir
        os.makedirs(model_dir, exist_ok=True)
        
        # Initialize agents
        self.dqn_agent = DQNAgentSB3(env, os.path.join(model_dir, "dqn_model.zip"))
        self.ppo_agent = PPOAgent(env, os.path.join(model_dir, "ppo_model.zip"))
        
        # Training metrics
        self.training_history = {
            'dqn': {'rewards': [], 'losses': []},
            'ppo': {'rewards': [], 'losses': []}
        }
    
    def train_dqn(self, timesteps: int = 10000) -> Dict[str, Any]:
        """Train DQN agent."""
        logger.info(f"Starting DQN training for {timesteps} timesteps")
        
        self.dqn_agent.train(timesteps)
        self.dqn_agent.save(os.path.join(self.model_dir, "dqn_model.zip"))
        
        # Evaluate performance
        eval_results = self.evaluate_agent(self.dqn_agent, episodes=10)
        
        return {
            'agent_type': 'DQN',
            'timesteps': timesteps,
            'evaluation': eval_results
        }
    
    def train_ppo(self, timesteps: int = 10000) -> Dict[str, Any]:
        """Train PPO agent."""
        logger.info(f"Starting PPO training for {timesteps} timesteps")
        
        self.ppo_agent.train(timesteps)
        self.ppo_agent.save(os.path.join(self.model_dir, "ppo_model.zip"))
        
        # Evaluate performance
        eval_results = self.evaluate_agent(self.ppo_agent, episodes=10)
        
        return {
            'agent_type': 'PPO',
            'timesteps': timesteps,
            'evaluation': eval_results
        }
    
    def evaluate_agent(self, agent, episodes: int = 10) -> Dict[str, float]:
        """Evaluate agent performance."""
        total_rewards = []
        detection_accuracies = []
        
        for episode in range(episodes):
            obs, _ = self.env.reset()
            episode_reward = 0
            correct_detections = 0
            total_detections = 0
            
            done = False
            while not done:
                action = agent.predict(obs)
                obs, reward, terminated, truncated, info = self.env.step(action)
                done = terminated or truncated
                episode_reward += reward
                
                # Track detection accuracy
                if 'correct_detections' in info:
                    correct_detections = info['correct_detections']
                    total_detections = correct_detections + info.get('false_positives', 0)
            
            total_rewards.append(episode_reward)
            if total_detections > 0:
                detection_accuracies.append(correct_detections / total_detections)
        
        return {
            'mean_reward': np.mean(total_rewards),
            'std_reward': np.std(total_rewards),
            'mean_accuracy': np.mean(detection_accuracies) if detection_accuracies else 0,
            'episodes_evaluated': episodes
        }
    
    def compare_agents(self, episodes: int = 20) -> Dict[str, Any]:
        """Compare performance of different agents."""
        dqn_results = self.evaluate_agent(self.dqn_agent, episodes)
        ppo_results = self.evaluate_agent(self.ppo_agent, episodes)
        
        comparison = {
            'DQN': dqn_results,
            'PPO': ppo_results,
            'winner': 'DQN' if dqn_results['mean_reward'] > ppo_results['mean_reward'] else 'PPO'
        }
        
        logger.info(f"Agent comparison completed. Winner: {comparison['winner']}")
        return comparison
    
    def get_best_agent(self):
        """Get the best performing agent."""
        comparison = self.compare_agents(episodes=5)
        if comparison['winner'] == 'DQN':
            return self.dqn_agent
        else:
            return self.ppo_agent