-- Initialize database schema for vulnerability scanner

-- Create extension for UUID generation
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- Scan results table
CREATE TABLE IF NOT EXISTS scan_results (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    scan_id VARCHAR(255) UNIQUE NOT NULL,
    url TEXT NOT NULL,
    status VARCHAR(50) NOT NULL DEFAULT 'pending',
    start_time TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    end_time TIMESTAMP WITH TIME ZONE,
    progress INTEGER DEFAULT 0,
    risk_score FLOAT DEFAULT 0.0,
    vulnerabilities JSONB DEFAULT '[]',
    scan_options JSONB DEFAULT '{}',
    ml_results JSONB DEFAULT '{}',
    rl_results JSONB DEFAULT '{}',
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Vulnerabilities table
CREATE TABLE IF NOT EXISTS vulnerabilities (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    scan_id VARCHAR(255) REFERENCES scan_results(scan_id),
    vuln_type VARCHAR(100) NOT NULL,
    name VARCHAR(255) NOT NULL,
    severity VARCHAR(50) NOT NULL,
    confidence FLOAT NOT NULL,
    description TEXT,
    remediation JSONB DEFAULT '[]',
    detected_by JSONB DEFAULT '[]',
    cwe VARCHAR(20),
    owasp VARCHAR(100),
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Model training logs table
CREATE TABLE IF NOT EXISTS training_logs (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    model_type VARCHAR(100) NOT NULL,
    model_name VARCHAR(255) NOT NULL,
    training_start TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    training_end TIMESTAMP WITH TIME ZONE,
    parameters JSONB DEFAULT '{}',
    metrics JSONB DEFAULT '{}',
    status VARCHAR(50) DEFAULT 'running',
    error_message TEXT,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Create indexes for better performance
CREATE INDEX IF NOT EXISTS idx_scan_results_scan_id ON scan_results(scan_id);
CREATE INDEX IF NOT EXISTS idx_scan_results_status ON scan_results(status);
CREATE INDEX IF NOT EXISTS idx_scan_results_created_at ON scan_results(created_at);
CREATE INDEX IF NOT EXISTS idx_vulnerabilities_scan_id ON vulnerabilities(scan_id);
CREATE INDEX IF NOT EXISTS idx_vulnerabilities_vuln_type ON vulnerabilities(vuln_type);
CREATE INDEX IF NOT EXISTS idx_training_logs_model_type ON training_logs(model_type);

-- Create function to update updated_at timestamp
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = NOW();
    RETURN NEW;
END;
$$ language 'plpgsql';

-- Create trigger for scan_results table
CREATE TRIGGER update_scan_results_updated_at
    BEFORE UPDATE ON scan_results
    FOR EACH ROW
    EXECUTE FUNCTION update_updated_at_column();