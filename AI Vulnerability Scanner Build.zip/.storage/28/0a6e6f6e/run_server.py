#!/usr/bin/env python3
"""
Production server runner for the vulnerability scanner API.
"""

import uvicorn
import sys
import os
from loguru import logger

# Add the backend directory to Python path
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

from config import settings

def main():
    """Run the FastAPI server."""
    # Configure logging
    logger.add("server.log", rotation="10 MB", level="INFO")
    logger.info("Starting Vulnerability Scanner API server...")
    
    # Run the server
    uvicorn.run(
        "api.main:app",
        host=settings.API_HOST,
        port=settings.API_PORT,
        reload=settings.DEBUG,
        workers=1 if settings.DEBUG else 4,
        log_level="info"
    )

if __name__ == "__main__":
    main()