import pytest
import pandas as pd
import numpy as np
from unittest.mock import patch, Mock
import tempfile
import os

from ..data_processing.dataset_loader import CSICDatasetLoader, load_and_preprocess_dataset

@pytest.fixture
def sample_csv_data():
    """Create sample CSV data for testing."""
    data = """Unnamed: 0|Method|Unnamed: 2|Pragma|Cache-Control|Accept|Accept-encoding|Accept-charset|language|host|Unnamed: 10|content-type|connection|lenght|content|classification
0|Normal|GET|NaN|no-cache|no-cache|text/html|gzip, deflate|utf-8|en|localhost:8080|NaN|NaN|close|NaN|NaN|0
1|Normal|POST|NaN|no-cache|no-cache|text/html|gzip, deflate|utf-8|en|localhost:8080|NaN|application/x-www-form-urlencoded|close|68|id=3&nombre=Vino|0
2|Anomalous|GET|NaN|no-cache|no-cache|text/html|gzip, deflate|utf-8|en|localhost:8080|NaN|NaN|close|NaN|' OR '1'='1|1
3|Anomalous|POST|NaN|no-cache|no-cache|text/html|gzip, deflate|utf-8|en|localhost:8080|NaN|application/x-www-form-urlencoded|close|50|<script>alert('xss')</script>|1"""
    return data

@pytest.fixture
def temp_csv_file(sample_csv_data):
    """Create temporary CSV file for testing."""
    with tempfile.NamedTemporaryFile(mode='w', suffix='.csv', delete=False) as f:
        f.write(sample_csv_data)
        temp_path = f.name
    
    yield temp_path
    
    # Cleanup
    os.unlink(temp_path)

def test_dataset_loader_initialization():
    """Test CSICDatasetLoader initialization."""
    loader = CSICDatasetLoader("test_path.csv")
    
    assert loader.dataset_path == "test_path.csv"
    assert hasattr(loader, 'label_encoder')
    assert hasattr(loader, 'scaler')
    assert hasattr(loader, 'tfidf_vectorizer')
    assert len(loader.vulnerability_types) > 0

def test_load_raw_data(temp_csv_file):
    """Test loading raw CSV data."""
    loader = CSICDatasetLoader(temp_csv_file)
    df = loader.load_raw_data()
    
    assert isinstance(df, pd.DataFrame)
    assert len(df) == 4
    assert 'Method' in df.columns
    assert 'classification' in df.columns

def test_extract_http_features(temp_csv_file):
    """Test HTTP feature extraction."""
    loader = CSICDatasetLoader(temp_csv_file)
    df = loader.load_raw_data()
    features_df = loader.extract_http_features(df)
    
    assert isinstance(features_df, pd.DataFrame)
    assert len(features_df) == len(df)
    assert 'method' in features_df.columns
    assert 'has_content' in features_df.columns
    assert 'content_has_sql_keywords' in features_df.columns
    assert 'content_has_script' in features_df.columns
    
    # Check SQL injection detection
    assert features_df.iloc[2]['content_has_sql_keywords'] == 1  # Row with SQL injection
    
    # Check XSS detection
    assert features_df.iloc[3]['content_has_script'] == 1  # Row with script tag

def test_encode_labels(temp_csv_file):
    """Test label encoding."""
    loader = CSICDatasetLoader(temp_csv_file)
    df = loader.load_raw_data()
    binary_labels, multiclass_labels = loader.encode_labels(df)
    
    assert len(binary_labels) == len(df)
    assert len(multiclass_labels) == len(df)
    assert set(binary_labels) <= {0, 1}  # Binary labels should be 0 or 1
    assert all(label >= 0 for label in multiclass_labels)  # All labels should be non-negative

def test_preprocess_data(temp_csv_file):
    """Test complete preprocessing pipeline."""
    loader = CSICDatasetLoader(temp_csv_file)
    result = loader.preprocess_data(test_size=0.5, random_state=42)
    
    # Check structure
    assert 'binary_classification' in result
    assert 'multiclass_classification' in result
    assert 'text_features' in result
    assert 'preprocessors' in result
    assert 'feature_names' in result
    assert 'vulnerability_types' in result
    
    # Check binary classification data
    binary_data = result['binary_classification']
    assert 'X_train' in binary_data
    assert 'X_test' in binary_data
    assert 'y_train' in binary_data
    assert 'y_test' in binary_data
    
    # Check shapes
    assert binary_data['X_train'].shape[1] == binary_data['X_test'].shape[1]
    assert len(binary_data['X_train']) == len(binary_data['y_train'])
    assert len(binary_data['X_test']) == len(binary_data['y_test'])

def test_load_and_preprocess_dataset_function(temp_csv_file):
    """Test the convenience function."""
    result = load_and_preprocess_dataset(temp_csv_file)
    
    assert isinstance(result, dict)
    assert 'binary_classification' in result
    assert 'feature_names' in result

def test_feature_extraction_edge_cases():
    """Test feature extraction with edge cases."""
    # Create DataFrame with edge cases
    df = pd.DataFrame({
        'Method': ['GET', 'POST', None],
        'content': [None, '', 'normal content'],
        'Accept': [None, 'text/html', 'application/json'],
        'content-type': [None, 'application/json', 'text/html'],
        'connection': ['close', None, 'keep-alive'],
        'lenght': [None, 0, 100],
        'Pragma': [None, 'no-cache', None],
        'Cache-Control': ['no-cache', None, 'max-age=3600'],
        'Accept-encoding': ['gzip', None, 'deflate'],
        'classification': [0, 1, 0]
    })
    
    loader = CSICDatasetLoader("dummy_path.csv")
    features_df = loader.extract_http_features(df)
    
    # Should handle NaN values gracefully
    assert not features_df.isnull().any().any()
    assert len(features_df) == len(df)

def test_vulnerability_classification_patterns():
    """Test vulnerability type classification based on content patterns."""
    df = pd.DataFrame({
        'content': [
            "SELECT * FROM users WHERE id = 1",  # SQL injection
            "<script>alert('xss')</script>",      # XSS
            "../../etc/passwd",                   # Path traversal
            "normal content",                     # Normal
            "javascript:alert('test')"            # XSS
        ],
        'classification': [1, 1, 1, 0, 1],
        'Method': ['GET'] * 5
    })
    
    # Add required columns with default values
    for col in ['Accept', 'content-type', 'connection', 'lenght', 'Pragma', 'Cache-Control', 'Accept-encoding']:
        df[col] = None
    
    loader = CSICDatasetLoader("dummy_path.csv")
    binary_labels, multiclass_labels = loader.encode_labels(df)
    
    # Check that SQL injection is detected (should be class 1)
    assert multiclass_labels[0] == 1  # SQL injection
    
    # Check that XSS is detected (should be class 2)
    assert multiclass_labels[1] == 2  # XSS
    assert multiclass_labels[4] == 2  # XSS
    
    # Check that path traversal is detected (should be class 4)
    assert multiclass_labels[2] == 4  # Path traversal
    
    # Check that normal content is class 0
    assert multiclass_labels[3] == 0  # Normal