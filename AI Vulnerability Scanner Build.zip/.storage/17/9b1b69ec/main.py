from fastapi import FastAPI, HTTPException, BackgroundTasks
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, HttpUrl
from typing import Dict, Any, Optional, List
import asyncio
from loguru import logger
import os

from ..comprehensive_scanner.scanner import get_scanner_instance
from ..config import settings

# Initialize FastAPI app
app = FastAPI(
    title="AI-Powered Vulnerability Scanner",
    description="Production-ready backend system for vulnerability scanning using ML and RL",
    version="1.0.0"
)

# Add CORS middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Pydantic models for request/response
class ScanRequest(BaseModel):
    url: HttpUrl
    scan_options: Optional[Dict[str, Any]] = {}

class ScanResponse(BaseModel):
    scan_id: str
    status: str
    message: str

class TrainingRequest(BaseModel):
    model_type: str  # 'baseline' or 'rl'
    parameters: Optional[Dict[str, Any]] = {}

class TrainingResponse(BaseModel):
    status: str
    results: Dict[str, Any]

# Global scanner instance
scanner = None

@app.on_event("startup")
async def startup_event():
    """Initialize the scanner on startup."""
    global scanner
    dataset_path = "/workspace/uploads/database.csv"
    
    if os.path.exists(dataset_path):
        scanner = get_scanner_instance(dataset_path, settings.MODEL_PATH)
        await scanner.initialize_models()
        logger.info("Scanner initialized successfully")
    else:
        logger.warning(f"Dataset not found at {dataset_path}")

@app.get("/")
async def root():
    """Root endpoint with API information."""
    return {
        "message": "AI-Powered Vulnerability Scanner API",
        "version": "1.0.0",
        "status": "running",
        "endpoints": {
            "scan": "POST /scan - Submit URL for vulnerability scanning",
            "results": "GET /results/{scan_id} - Get scan results",
            "recommendations": "GET /recommendations/{vuln_id} - Get remediation advice",
            "train_baseline": "POST /train/baseline - Train baseline ML models",
            "train_rl": "POST /train/rl - Train RL agents"
        }
    }

@app.get("/health")
async def health_check():
    """Health check endpoint."""
    return {
        "status": "healthy",
        "scanner_initialized": scanner is not None,
        "timestamp": "2025-01-27T10:00:00Z"
    }

@app.post("/scan", response_model=ScanResponse)
async def submit_scan(scan_request: ScanRequest):
    """
    Submit a URL for vulnerability scanning.
    Returns scan_id for tracking progress.
    """
    if scanner is None:
        raise HTTPException(status_code=503, detail="Scanner not initialized")
    
    try:
        url = str(scan_request.url)
        scan_id = await scanner.scan_url(url, scan_request.scan_options)
        
        return ScanResponse(
            scan_id=scan_id,
            status="submitted",
            message=f"Scan submitted successfully. Use scan_id {scan_id} to track progress."
        )
    
    except Exception as e:
        logger.error(f"Error submitting scan: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@app.get("/results/{scan_id}")
async def get_scan_results(scan_id: str):
    """
    Retrieve vulnerability scan results by scan_id.
    """
    if scanner is None:
        raise HTTPException(status_code=503, detail="Scanner not initialized")
    
    results = scanner.get_scan_results(scan_id)
    
    if results is None:
        raise HTTPException(status_code=404, detail="Scan not found")
    
    return results

@app.get("/recommendations/{vuln_id}")
async def get_vulnerability_recommendations(vuln_id: str):
    """
    Get detailed remediation recommendations for a specific vulnerability.
    """
    if scanner is None:
        raise HTTPException(status_code=503, detail="Scanner not initialized")
    
    recommendations = scanner.get_vulnerability_recommendations(vuln_id)
    
    if "error" in recommendations:
        raise HTTPException(status_code=404, detail=recommendations["error"])
    
    return recommendations

@app.post("/train/baseline", response_model=TrainingResponse)
async def train_baseline_models(training_request: TrainingRequest):
    """
    Train baseline ML models (Logistic Regression, Random Forest, SVM, Neural Network).
    """
    if scanner is None:
        raise HTTPException(status_code=503, detail="Scanner not initialized")
    
    try:
        logger.info("Starting baseline model training...")
        results = await scanner.train_baseline_models()
        
        return TrainingResponse(
            status="completed",
            results=results
        )
    
    except Exception as e:
        logger.error(f"Error training baseline models: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@app.post("/train/rl", response_model=TrainingResponse)
async def train_rl_agents(training_request: TrainingRequest):
    """
    Train Reinforcement Learning agents (DQN and PPO).
    """
    if scanner is None:
        raise HTTPException(status_code=503, detail="Scanner not initialized")
    
    try:
        timesteps = training_request.parameters.get("timesteps", 10000)
        logger.info(f"Starting RL agent training with {timesteps} timesteps...")
        
        results = await scanner.train_rl_agents(timesteps)
        
        return TrainingResponse(
            status="completed",
            results=results
        )
    
    except Exception as e:
        logger.error(f"Error training RL agents: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@app.get("/models/status")
async def get_model_status():
    """Get status of all trained models."""
    if scanner is None:
        raise HTTPException(status_code=503, detail="Scanner not initialized")
    
    try:
        # Check baseline models
        baseline_status = {}
        if scanner.baseline_models.model_performance:
            baseline_status = scanner.baseline_models.model_performance
        
        # Check RL models
        rl_status = {}
        if scanner.rl_trainer:
            rl_status = {
                "dqn_available": os.path.exists(os.path.join(settings.MODEL_PATH, "dqn_model.zip")),
                "ppo_available": os.path.exists(os.path.join(settings.MODEL_PATH, "ppo_model.zip"))
            }
        
        return {
            "baseline_models": baseline_status,
            "rl_models": rl_status,
            "model_directory": settings.MODEL_PATH
        }
    
    except Exception as e:
        logger.error(f"Error getting model status: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@app.get("/scans/active")
async def get_active_scans():
    """Get list of all active scans."""
    if scanner is None:
        raise HTTPException(status_code=503, detail="Scanner not initialized")
    
    active_scans = []
    for scan_id, scan_data in scanner.scan_results.items():
        if scan_data.get('status') == 'running':
            active_scans.append({
                'scan_id': scan_id,
                'url': scan_data.get('url'),
                'progress': scan_data.get('progress', 0),
                'start_time': scan_data.get('start_time'),
                'current_task': scan_data.get('current_task', 'Processing...')
            })
    
    return {
        "active_scans": active_scans,
        "total_active": len(active_scans)
    }

@app.get("/vulnerabilities/types")
async def get_vulnerability_types():
    """Get information about supported vulnerability types."""
    if scanner is None:
        raise HTTPException(status_code=503, detail="Scanner not initialized")
    
    return {
        "supported_types": scanner.vulnerability_kb,
        "total_types": len(scanner.vulnerability_kb)
    }

@app.delete("/scans/{scan_id}")
async def delete_scan_results(scan_id: str):
    """Delete scan results by scan_id."""
    if scanner is None:
        raise HTTPException(status_code=503, detail="Scanner not initialized")
    
    if scan_id not in scanner.scan_results:
        raise HTTPException(status_code=404, detail="Scan not found")
    
    del scanner.scan_results[scan_id]
    return {"message": f"Scan {scan_id} deleted successfully"}

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host=settings.API_HOST, port=settings.API_PORT)