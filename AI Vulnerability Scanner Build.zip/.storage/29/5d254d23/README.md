# AI-Powered Vulnerability Scanner Backend

A production-ready backend system for vulnerability scanning using Machine Learning and Reinforcement Learning, built with the CSIC 2010 dataset.

## Features

- **Dataset Processing**: Complete preprocessing pipeline for the CSIC 2010 dataset
- **Baseline ML Models**: Logistic Regression, Random Forest, SVM, Neural Networks
- **Reinforcement Learning**: DQN and PPO agents for intelligent vulnerability detection
- **RESTful API**: FastAPI-based API with comprehensive endpoints
- **Docker Support**: Complete containerized deployment
- **Production Ready**: Nginx proxy, PostgreSQL, Redis, monitoring

## Project Structure

```
backend/
├── ai_models/              # Trained ML and RL models
├── api/                    # FastAPI application
├── attack_simulation/      # RL environment and attack simulation
├── comprehensive_scanner/  # Main scanner orchestration
├── data_processing/        # Dataset loading and preprocessing
├── tests/                  # Unit tests
├── config.py              # Configuration settings
├── requirements.txt       # Python dependencies
├── Dockerfile             # Docker container definition
├── docker-compose.yml     # Multi-service deployment
└── README.md              # This file
```

## Quick Start

### 1. Using Docker (Recommended)

```bash
# Clone and navigate to the backend directory
cd backend/

# Start all services
docker-compose up -d

# Check service status
docker-compose ps

# View logs
docker-compose logs -f api
```

The API will be available at `http://localhost:8000`

### 2. Local Development

```bash
# Install dependencies
pip install -r requirements.txt

# Set environment variables
export DATASET_PATH="/path/to/database.csv"

# Initialize models (optional - will be done automatically)
python train_models.py --dataset /path/to/database.csv --type all

# Run the server
python run_server.py
```

## API Endpoints

### Core Scanning

- `POST /scan` - Submit URL for vulnerability scanning
- `GET /results/{scan_id}` - Get scan results
- `GET /recommendations/{vuln_id}` - Get remediation advice

### Model Training

- `POST /train/baseline` - Train baseline ML models
- `POST /train/rl` - Train RL agents

### System Information

- `GET /health` - Health check
- `GET /models/status` - Model training status
- `GET /vulnerabilities/types` - Supported vulnerability types

## Usage Examples

### 1. Submit a Scan

```bash
curl -X POST "http://localhost:8000/scan" \
     -H "Content-Type: application/json" \
     -d '{"url": "https://example.com", "scan_options": {}}'
```

Response:
```json
{
  "scan_id": "abc123-def456-ghi789",
  "status": "submitted",
  "message": "Scan submitted successfully..."
}
```

### 2. Get Scan Results

```bash
curl "http://localhost:8000/results/abc123-def456-ghi789"
```

Response:
```json
{
  "scan_id": "abc123-def456-ghi789",
  "status": "completed",
  "vulnerabilities": [
    {
      "id": "vuln-001",
      "name": "SQL Injection",
      "severity": "High",
      "confidence": 0.89,
      "detected_by": ["ML", "RL"]
    }
  ],
  "risk_score": 75.5
}
```

### 3. Train Models

```bash
# Train baseline models
curl -X POST "http://localhost:8000/train/baseline" \
     -H "Content-Type: application/json" \
     -d '{"model_type": "baseline"}'

# Train RL agents
curl -X POST "http://localhost:8000/train/rl" \
     -H "Content-Type: application/json" \
     -d '{"model_type": "rl", "parameters": {"timesteps": 20000}}'
```

## Architecture

### MDP + RL Environment

The system implements an OpenAI Gym-style environment:

- **State**: Current request features + scanning progress
- **Actions**: 10 different scanning techniques (SQL injection probes, XSS payloads, etc.)
- **Rewards**: 
  - +1 for correct vulnerability detection
  - -1 for false positives
  - +2 for suggesting correct fixes

### Baseline Models

- **Logistic Regression**: Linear classification baseline
- **Random Forest**: Ensemble method for robust detection
- **SVM**: Support Vector Machine with RBF kernel
- **Neural Network**: Multi-layer perceptron with dropout

### RL Agents

- **DQN**: Deep Q-Network for value-based learning
- **PPO**: Proximal Policy Optimization for policy-based learning

## Configuration

Key configuration options in `config.py`:

```python
# API Settings
API_HOST = "0.0.0.0"
API_PORT = 8000

# Database Settings
POSTGRES_HOST = "localhost"
POSTGRES_DB = "vuln_scanner"

# ML Settings
RL_EPISODES = 1000
RL_BATCH_SIZE = 32
```

## Testing

Run the test suite:

```bash
# Install test dependencies
pip install pytest pytest-asyncio

# Run all tests
pytest tests/ -v

# Run specific test file
pytest tests/test_api.py -v

# Run with coverage
pytest tests/ --cov=backend --cov-report=html
```

## Monitoring

The system includes optional monitoring with Prometheus and Grafana:

- **Prometheus**: `http://localhost:9090`
- **Grafana**: `http://localhost:3000` (admin/admin)

## Production Deployment

### Environment Variables

```bash
# Required
DATASET_PATH=/path/to/database.csv
POSTGRES_PASSWORD=secure_password
SECRET_KEY=your-secret-key

# Optional
DEBUG=false
POSTGRES_HOST=postgres
REDIS_HOST=redis
```

### SSL Configuration

1. Place SSL certificates in `ssl/` directory
2. Update `nginx.conf` for HTTPS configuration
3. Restart services: `docker-compose restart nginx`

### Scaling

Scale API instances:
```bash
docker-compose up -d --scale api=3
```

## Development

### Adding New Vulnerability Types

1. Update `vulnerability_kb` in `scanner.py`
2. Add detection patterns in `dataset_loader.py`
3. Update RL environment actions in `rl_environment.py`
4. Add tests in `tests/`

### Custom ML Models

1. Implement model in `baseline_models.py`
2. Add training logic in `train_sklearn_models()`
3. Update API endpoints if needed

## Troubleshooting

### Common Issues

1. **Dataset not found**: Ensure the CSV file path is correct
2. **Memory issues**: Reduce batch sizes in training parameters
3. **Port conflicts**: Change ports in `docker-compose.yml`

### Logs

```bash
# API logs
docker-compose logs api

# Database logs
docker-compose logs postgres

# All services
docker-compose logs
```

## Contributing

1. Fork the repository
2. Create a feature branch
3. Add tests for new functionality
4. Ensure all tests pass
5. Submit a pull request

## License

This project is licensed under the MIT License.