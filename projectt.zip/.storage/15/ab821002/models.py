from sqlalchemy import Column, Integer, String, Text, DateTime, ForeignKey, Boolean
from sqlalchemy.orm import relationship
from sqlalchemy.sql import func
from .database import Base

class ScanResult(Base):
    __tablename__ = "scan_results"
    
    id = Column(Integer, primary_key=True, index=True)
    filename = Column(String(255), nullable=False)
    language = Column(String(50), nullable=False)
    code_hash = Column(Integer, nullable=False)
    vulnerabilities_found = Column(Integer, default=0)
    scan_status = Column(String(50), default="pending")
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    updated_at = Column(DateTime(timezone=True), onupdate=func.now())
    
    # Relationship to vulnerability reports
    vulnerabilities = relationship("VulnerabilityReport", back_populates="scan")

class VulnerabilityReport(Base):
    __tablename__ = "vulnerability_reports"
    
    id = Column(Integer, primary_key=True, index=True)
    scan_id = Column(Integer, ForeignKey("scan_results.id"), nullable=False)
    vulnerability_type = Column(String(100), nullable=False)
    severity = Column(String(20), nullable=False)
    line_number = Column(Integer, default=0)
    description = Column(Text, nullable=False)
    recommendation = Column(Text)
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    
    # Relationship to scan result
    scan = relationship("ScanResult", back_populates="vulnerabilities")

class DatasetMetadata(Base):
    __tablename__ = "dataset_metadata"
    
    id = Column(Integer, primary_key=True, index=True)
    dataset_name = Column(String(100), nullable=False)
    version = Column(String(20), nullable=False)
    total_samples = Column(Integer, default=0)
    vulnerability_types = Column(Text)  # JSON string
    last_updated = Column(DateTime(timezone=True), server_default=func.now())
    is_active = Column(Boolean, default=True)