import pandas as pd
import numpy as np
import os
import json
import logging
from typing import Dict, List, Tuple, Optional
from sklearn.model_selection import train_test_split
from sklearn.feature_extraction.text import TfidfVectorizer
import joblib

logger = logging.getLogger(__name__)

class DatasetLoader:
    """Handles loading and preprocessing of vulnerability datasets"""
    
    def __init__(self):
        self.dataset_path = "/app/datasets"
        self.models_path = "/app/models"
        self.dataset = None
        self.vectorizer = None
        self.is_loaded = False
        
        # Create directories if they don't exist
        os.makedirs(self.dataset_path, exist_ok=True)
        os.makedirs(self.models_path, exist_ok=True)
        
        # Vulnerability patterns for synthetic data generation
        self.vulnerability_patterns = {
            "sql_injection": [
                "SELECT * FROM users WHERE id = '" + "' OR '1'='1",
                "query = \"SELECT * FROM table WHERE id = \" + user_input",
                "cursor.execute(\"SELECT * FROM users WHERE name = '%s'\" % username)",
                "db.query(f\"SELECT * FROM products WHERE id = {product_id}\")"
            ],
            "xss": [
                "document.write(userInput)",
                "innerHTML = userInput",
                "eval(userInput)",
                "<script>alert('xss')</script>"
            ],
            "buffer_overflow": [
                "strcpy(buffer, input)",
                "gets(buffer)",
                "sprintf(buffer, \"%s\", input)",
                "memcpy(dest, src, strlen(src))"
            ],
            "path_traversal": [
                "open('../../../etc/passwd')",
                "file_path = base_path + user_input",
                "readFile(request.getParameter('file'))",
                "include($_GET['page'] . '.php')"
            ],
            "command_injection": [
                "os.system(user_input)",
                "exec(user_command)",
                "subprocess.call(shell_command, shell=True)",
                "system(\"ping \" + ip_address)"
            ]
        }
    
    def generate_synthetic_dataset(self) -> pd.DataFrame:
        """Generate synthetic vulnerability dataset for training"""
        logger.info("Generating synthetic vulnerability dataset...")
        
        data = []
        
        # Generate vulnerable code samples
        for vuln_type, patterns in self.vulnerability_patterns.items():
            for pattern in patterns:
                for i in range(10):  # Generate 10 variations per pattern
                    # Create variations of the vulnerable pattern
                    variations = [
                        pattern,
                        f"// Vulnerable code\n{pattern}",
                        f"if (condition) {{\n    {pattern}\n}}",
                        f"function vulnerable() {{\n    {pattern}\n    return result;\n}}",
                        f"try {{\n    {pattern}\n}} catch (e) {{}}",
                    ]
                    
                    for variation in variations:
                        data.append({
                            'code': variation,
                            'vulnerability_type': vuln_type,
                            'is_vulnerable': 1,
                            'severity': np.random.choice(['low', 'medium', 'high'], p=[0.2, 0.5, 0.3]),
                            'language': np.random.choice(['python', 'javascript', 'java', 'c', 'php'])
                        })
        
        # Generate safe code samples
        safe_patterns = [
            "user_id = int(request.form['id'])\nuser = User.objects.get(id=user_id)",
            "sanitized_input = html.escape(user_input)\noutput.write(sanitized_input)",
            "if len(buffer) < MAX_SIZE:\n    strncpy(buffer, input, MAX_SIZE-1)",
            "if os.path.basename(file_path) == file_path:\n    open(safe_path + file_path)",
            "subprocess.run(['ping', '-c', '1', validated_ip], check=True)"
        ]
        
        for pattern in safe_patterns:
            for i in range(20):  # Generate more safe samples
                data.append({
                    'code': pattern,
                    'vulnerability_type': 'safe',
                    'is_vulnerable': 0,
                    'severity': 'none',
                    'language': np.random.choice(['python', 'javascript', 'java', 'c', 'php'])
                })
        
        df = pd.DataFrame(data)
        logger.info(f"Generated {len(df)} synthetic samples")
        return df
    
    def load_dataset(self) -> bool:
        """Load vulnerability dataset from files or generate synthetic data"""
        try:
            logger.info("Loading vulnerability dataset...")
            
            # Try to load existing dataset
            dataset_file = os.path.join(self.dataset_path, "vulnerability_dataset.csv")
            
            if os.path.exists(dataset_file):
                logger.info(f"Loading dataset from {dataset_file}")
                self.dataset = pd.read_csv(dataset_file)
            else:
                logger.info("No existing dataset found, generating synthetic data...")
                self.dataset = self.generate_synthetic_dataset()
                
                # Save the generated dataset
                self.dataset.to_csv(dataset_file, index=False)
                logger.info(f"Saved synthetic dataset to {dataset_file}")
            
            # Validate dataset
            if self.dataset is None or len(self.dataset) == 0:
                raise ValueError("Dataset is empty or could not be loaded")
            
            # Check required columns
            required_columns = ['code', 'vulnerability_type', 'is_vulnerable']
            missing_columns = [col for col in required_columns if col not in self.dataset.columns]
            if missing_columns:
                raise ValueError(f"Dataset missing required columns: {missing_columns}")
            
            logger.info(f"Dataset loaded successfully: {len(self.dataset)} samples")
            logger.info(f"Vulnerability types: {self.dataset['vulnerability_type'].unique()}")
            
            self.is_loaded = True
            return True
            
        except Exception as e:
            logger.error(f"Failed to load dataset: {str(e)}")
            self.is_loaded = False
            return False
    
    def preprocess_data(self) -> Tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray]:
        """Preprocess the dataset for machine learning"""
        if not self.is_loaded or self.dataset is None:
            raise ValueError("Dataset not loaded. Call load_dataset() first.")
        
        logger.info("Preprocessing dataset...")
        
        # Extract features and labels
        X = self.dataset['code'].values
        y = self.dataset['is_vulnerable'].values
        
        # Initialize or load vectorizer
        vectorizer_path = os.path.join(self.models_path, "tfidf_vectorizer.joblib")
        
        if os.path.exists(vectorizer_path):
            logger.info("Loading existing TF-IDF vectorizer...")
            self.vectorizer = joblib.load(vectorizer_path)
            X_vectorized = self.vectorizer.transform(X)
        else:
            logger.info("Creating new TF-IDF vectorizer...")
            self.vectorizer = TfidfVectorizer(
                max_features=5000,
                ngram_range=(1, 3),
                stop_words='english',
                lowercase=True,
                token_pattern=r'\b\w+\b'
            )
            X_vectorized = self.vectorizer.fit_transform(X)
            
            # Save vectorizer
            joblib.dump(self.vectorizer, vectorizer_path)
            logger.info(f"Saved TF-IDF vectorizer to {vectorizer_path}")
        
        # Split the data
        X_train, X_test, y_train, y_test = train_test_split(
            X_vectorized, y, test_size=0.2, random_state=42, stratify=y
        )
        
        logger.info(f"Data preprocessing completed:")
        logger.info(f"Training samples: {X_train.shape[0]}")
        logger.info(f"Test samples: {X_test.shape[0]}")
        logger.info(f"Features: {X_train.shape[1]}")
        
        return X_train, X_test, y_train, y_test
    
    def get_vulnerability_details(self, vuln_type: str) -> Dict:
        """Get detailed information about a vulnerability type"""
        vulnerability_info = {
            "sql_injection": {
                "description": "SQL injection vulnerability allows attackers to execute malicious SQL commands",
                "severity": "high",
                "recommendation": "Use parameterized queries and input validation"
            },
            "xss": {
                "description": "Cross-site scripting allows injection of malicious scripts",
                "severity": "medium",
                "recommendation": "Sanitize user input and use content security policy"
            },
            "buffer_overflow": {
                "description": "Buffer overflow can lead to code execution or system crash",
                "severity": "high",
                "recommendation": "Use safe string functions and bounds checking"
            },
            "path_traversal": {
                "description": "Path traversal allows access to files outside intended directory",
                "severity": "medium",
                "recommendation": "Validate and sanitize file paths, use whitelist approach"
            },
            "command_injection": {
                "description": "Command injection allows execution of arbitrary system commands",
                "severity": "high",
                "recommendation": "Avoid system calls with user input, use safe APIs"
            }
        }
        
        return vulnerability_info.get(vuln_type, {
            "description": "Unknown vulnerability type",
            "severity": "medium",
            "recommendation": "Review code for security issues"
        })
    
    def is_dataset_loaded(self) -> bool:
        """Check if dataset is loaded"""
        return self.is_loaded and self.dataset is not None
    
    def get_dataset_stats(self) -> Dict:
        """Get statistics about the loaded dataset"""
        if not self.is_loaded or self.dataset is None:
            return {"error": "Dataset not loaded"}
        
        return {
            "total_samples": len(self.dataset),
            "vulnerable_samples": len(self.dataset[self.dataset['is_vulnerable'] == 1]),
            "safe_samples": len(self.dataset[self.dataset['is_vulnerable'] == 0]),
            "vulnerability_types": self.dataset['vulnerability_type'].value_counts().to_dict(),
            "languages": self.dataset['language'].value_counts().to_dict() if 'language' in self.dataset.columns else {}
        }