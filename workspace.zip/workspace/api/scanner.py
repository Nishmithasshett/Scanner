import numpy as np
import joblib
import os
import re
import logging
from typing import List, Dict, Any, Optional
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import classification_report, accuracy_score
from .dataset_loader import DatasetLoader

logger = logging.getLogger(__name__)

class VulnerabilityScanner:
    """AI-powered vulnerability scanner"""
    
    def __init__(self, dataset_loader: DatasetLoader):
        self.dataset_loader = dataset_loader
        self.model = None
        self.model_path = "/app/models/vulnerability_model.joblib"
        self.is_trained = False
        
        # Vulnerability detection patterns (rule-based fallback)
        self.vulnerability_patterns = {
            "sql_injection": [
                r"SELECT.*FROM.*WHERE.*=.*\+",
                r"cursor\.execute\(.*%.*\)",
                r"query.*=.*\+.*input",
                r"WHERE.*=.*\'\s*\+",
                r"UNION.*SELECT",
                r"OR\s+1\s*=\s*1"
            ],
            "xss": [
                r"document\.write\(",
                r"innerHTML\s*=",
                r"eval\s*\(",
                r"<script.*>",
                r"javascript:",
                r"onload\s*="
            ],
            "buffer_overflow": [
                r"strcpy\s*\(",
                r"gets\s*\(",
                r"sprintf\s*\(",
                r"strcat\s*\(",
                r"memcpy\s*\([^,]*,[^,]*,\s*strlen"
            ],
            "path_traversal": [
                r"\.\./",
                r"\.\.\\",
                r"file_path.*\+.*input",
                r"open\s*\(.*\+",
                r"include.*\$_GET",
                r"require.*\$_POST"
            ],
            "command_injection": [
                r"os\.system\s*\(",
                r"exec\s*\(",
                r"subprocess.*shell\s*=\s*True",
                r"system\s*\(",
                r"popen\s*\(",
                r"shell_exec\s*\("
            ]
        }
    
    def train_model(self) -> bool:
        """Train the vulnerability detection model"""
        try:
            logger.info("Training vulnerability detection model...")
            
            # Check if model already exists and is recent
            if os.path.exists(self.model_path):
                logger.info("Loading existing trained model...")
                self.model = joblib.load(self.model_path)
                self.is_trained = True
                logger.info("Model loaded successfully")
                return True
            
            # Ensure dataset is loaded
            if not self.dataset_loader.is_dataset_loaded():
                logger.info("Dataset not loaded, loading now...")
                if not self.dataset_loader.load_dataset():
                    raise ValueError("Failed to load dataset")
            
            # Preprocess data
            X_train, X_test, y_train, y_test = self.dataset_loader.preprocess_data()
            
            # Train Random Forest model
            logger.info("Training Random Forest classifier...")
            self.model = RandomForestClassifier(
                n_estimators=100,
                max_depth=10,
                random_state=42,
                n_jobs=-1
            )
            
            self.model.fit(X_train, y_train)
            
            # Evaluate model
            y_pred = self.model.predict(X_test)
            accuracy = accuracy_score(y_test, y_pred)
            
            logger.info(f"Model training completed with accuracy: {accuracy:.4f}")
            logger.info("Classification Report:")
            logger.info(classification_report(y_test, y_pred))
            
            # Save the trained model
            os.makedirs(os.path.dirname(self.model_path), exist_ok=True)
            joblib.dump(self.model, self.model_path)
            logger.info(f"Model saved to {self.model_path}")
            
            self.is_trained = True
            return True
            
        except Exception as e:
            logger.error(f"Model training failed: {str(e)}")
            self.is_trained = False
            return False
    
    def scan_code(self, code: str, language: str = "python") -> List[Dict[str, Any]]:
        """Scan code for vulnerabilities using both ML and rule-based approaches"""
        vulnerabilities = []
        
        try:
            # ML-based detection
            if self.is_trained and self.model is not None:
                ml_vulnerabilities = self._ml_scan(code)
                vulnerabilities.extend(ml_vulnerabilities)
            
            # Rule-based detection (fallback and additional coverage)
            rule_vulnerabilities = self._rule_based_scan(code, language)
            
            # Merge and deduplicate vulnerabilities
            vulnerabilities.extend(rule_vulnerabilities)
            vulnerabilities = self._deduplicate_vulnerabilities(vulnerabilities)
            
            logger.info(f"Scan completed: found {len(vulnerabilities)} vulnerabilities")
            return vulnerabilities
            
        except Exception as e:
            logger.error(f"Code scanning failed: {str(e)}")
            # Return rule-based results as fallback
            return self._rule_based_scan(code, language)
    
    def _ml_scan(self, code: str) -> List[Dict[str, Any]]:
        """Perform ML-based vulnerability detection"""
        vulnerabilities = []
        
        try:
            if not self.dataset_loader.vectorizer:
                logger.warning("Vectorizer not available for ML scanning")
                return vulnerabilities
            
            # Vectorize the code
            code_vector = self.dataset_loader.vectorizer.transform([code])
            
            # Predict vulnerability
            prediction = self.model.predict(code_vector)[0]
            probability = self.model.predict_proba(code_vector)[0]
            
            if prediction == 1:  # Vulnerable
                confidence = max(probability)
                severity = "high" if confidence > 0.8 else "medium" if confidence > 0.6 else "low"
                
                vulnerabilities.append({
                    "type": "ml_detected_vulnerability",
                    "severity": severity,
                    "confidence": float(confidence),
                    "description": f"ML model detected potential vulnerability (confidence: {confidence:.2f})",
                    "recommendation": "Review code for security issues identified by ML model",
                    "detection_method": "machine_learning"
                })
            
        except Exception as e:
            logger.error(f"ML scanning failed: {str(e)}")
        
        return vulnerabilities
    
    def _rule_based_scan(self, code: str, language: str) -> List[Dict[str, Any]]:
        """Perform rule-based vulnerability detection"""
        vulnerabilities = []
        lines = code.split('\n')
        
        for vuln_type, patterns in self.vulnerability_patterns.items():
            for pattern in patterns:
                matches = re.finditer(pattern, code, re.IGNORECASE | re.MULTILINE)
                
                for match in matches:
                    # Find line number
                    line_num = code[:match.start()].count('\n') + 1
                    
                    # Get vulnerability details
                    vuln_details = self.dataset_loader.get_vulnerability_details(vuln_type)
                    
                    vulnerability = {
                        "type": vuln_type,
                        "severity": vuln_details.get("severity", "medium"),
                        "line": line_num,
                        "description": vuln_details.get("description", f"{vuln_type} vulnerability detected"),
                        "recommendation": vuln_details.get("recommendation", "Review and fix the identified issue"),
                        "pattern_matched": pattern,
                        "detection_method": "rule_based"
                    }
                    
                    vulnerabilities.append(vulnerability)
        
        return vulnerabilities
    
    def _deduplicate_vulnerabilities(self, vulnerabilities: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        """Remove duplicate vulnerabilities"""
        seen = set()
        unique_vulnerabilities = []
        
        for vuln in vulnerabilities:
            # Create a unique key based on type, line, and detection method
            key = (vuln.get("type"), vuln.get("line", 0), vuln.get("detection_method"))
            
            if key not in seen:
                seen.add(key)
                unique_vulnerabilities.append(vuln)
        
        return unique_vulnerabilities
    
    def is_model_ready(self) -> bool:
        """Check if the model is ready for scanning"""
        return self.is_trained and self.model is not None
    
    def get_model_info(self) -> Dict[str, Any]:
        """Get information about the trained model"""
        if not self.is_trained:
            return {"status": "not_trained", "model_path": self.model_path}
        
        model_stats = {
            "status": "trained",
            "model_type": "RandomForestClassifier",
            "model_path": self.model_path,
            "model_exists": os.path.exists(self.model_path)
        }
        
        if self.model:
            model_stats.update({
                "n_estimators": getattr(self.model, 'n_estimators', 'unknown'),
                "max_depth": getattr(self.model, 'max_depth', 'unknown'),
                "n_features": getattr(self.model, 'n_features_in_', 'unknown')
            })
        
        return model_stats
    
    def retrain_model(self) -> bool:
        """Force retrain the model"""
        logger.info("Force retraining model...")
        
        # Remove existing model
        if os.path.exists(self.model_path):
            os.remove(self.model_path)
        
        self.model = None
        self.is_trained = False
        
        # Retrain
        return self.train_model()