from pydantic import BaseModel
from datetime import datetime
from typing import List, Dict, Any, Optional

class ScanRequest(BaseModel):
    filename: str
    code: str
    language: str

class VulnerabilityInfo(BaseModel):
    type: str
    severity: str
    line: Optional[int] = None
    description: str
    recommendation: Optional[str] = None

class ScanResponse(BaseModel):
    scan_id: int
    filename: str
    vulnerabilities: List[Dict[str, Any]]
    total_vulnerabilities: int
    scan_status: str
    timestamp: datetime

class HealthResponse(BaseModel):
    status: str
    timestamp: datetime
    model_ready: bool
    dataset_loaded: bool
    version: str

class StatsResponse(BaseModel):
    total_scans: int
    total_vulnerabilities: int
    model_status: bool
    dataset_status: bool