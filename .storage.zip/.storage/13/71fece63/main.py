from fastapi import FastAPI, HTTPException, Depends, BackgroundTasks
from fastapi.middleware.cors import CORSMiddleware
from sqlalchemy.orm import Session
import logging
import os
from datetime import datetime
from typing import List, Dict, Any

from .database import get_db, engine
from .models import Base, ScanResult, VulnerabilityReport
from .scanner import VulnerabilityScanner
from .dataset_loader import DatasetLoader
from .schemas import ScanRequest, ScanResponse, HealthResponse

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Create tables
Base.metadata.create_all(bind=engine)

# Initialize FastAPI app
app = FastAPI(
    title="AI Vulnerability Scanner",
    description="Advanced AI-powered vulnerability scanner for code analysis",
    version="1.0.0"
)

# Configure CORS
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Initialize components
dataset_loader = DatasetLoader()
scanner = VulnerabilityScanner(dataset_loader)

@app.on_event("startup")
async def startup_event():
    """Initialize the application on startup"""
    try:
        logger.info("Starting AI Vulnerability Scanner...")
        
        # Load dataset and train model
        logger.info("Loading dataset...")
        dataset_loader.load_dataset()
        
        logger.info("Training vulnerability detection model...")
        scanner.train_model()
        
        logger.info("Application startup completed successfully")
    except Exception as e:
        logger.error(f"Startup failed: {str(e)}")
        raise

@app.get("/health", response_model=HealthResponse)
async def health_check():
    """Health check endpoint"""
    try:
        # Check if model is loaded
        model_status = scanner.is_model_ready()
        dataset_status = dataset_loader.is_dataset_loaded()
        
        return HealthResponse(
            status="healthy" if model_status and dataset_status else "unhealthy",
            timestamp=datetime.utcnow(),
            model_ready=model_status,
            dataset_loaded=dataset_status,
            version="1.0.0"
        )
    except Exception as e:
        logger.error(f"Health check failed: {str(e)}")
        raise HTTPException(status_code=500, detail="Health check failed")

@app.post("/scan", response_model=ScanResponse)
async def scan_code(
    request: ScanRequest,
    background_tasks: BackgroundTasks,
    db: Session = Depends(get_db)
):
    """Scan code for vulnerabilities"""
    try:
        logger.info(f"Starting vulnerability scan for: {request.filename}")
        
        # Perform vulnerability scan
        vulnerabilities = scanner.scan_code(request.code, request.language)
        
        # Create scan result record
        scan_result = ScanResult(
            filename=request.filename,
            language=request.language,
            code_hash=hash(request.code),
            vulnerabilities_found=len(vulnerabilities),
            scan_status="completed"
        )
        
        db.add(scan_result)
        db.commit()
        db.refresh(scan_result)
        
        # Save vulnerability reports
        for vuln in vulnerabilities:
            vuln_report = VulnerabilityReport(
                scan_id=scan_result.id,
                vulnerability_type=vuln["type"],
                severity=vuln["severity"],
                line_number=vuln.get("line", 0),
                description=vuln["description"],
                recommendation=vuln.get("recommendation", "")
            )
            db.add(vuln_report)
        
        db.commit()
        
        logger.info(f"Scan completed. Found {len(vulnerabilities)} vulnerabilities")
        
        return ScanResponse(
            scan_id=scan_result.id,
            filename=request.filename,
            vulnerabilities=vulnerabilities,
            total_vulnerabilities=len(vulnerabilities),
            scan_status="completed",
            timestamp=scan_result.created_at
        )
        
    except Exception as e:
        logger.error(f"Scan failed: {str(e)}")
        raise HTTPException(status_code=500, detail=f"Scan failed: {str(e)}")

@app.get("/scan/{scan_id}")
async def get_scan_result(scan_id: int, db: Session = Depends(get_db)):
    """Get scan result by ID"""
    try:
        scan_result = db.query(ScanResult).filter(ScanResult.id == scan_id).first()
        if not scan_result:
            raise HTTPException(status_code=404, detail="Scan result not found")
        
        vulnerabilities = db.query(VulnerabilityReport).filter(
            VulnerabilityReport.scan_id == scan_id
        ).all()
        
        return {
            "scan_id": scan_result.id,
            "filename": scan_result.filename,
            "language": scan_result.language,
            "vulnerabilities_found": scan_result.vulnerabilities_found,
            "scan_status": scan_result.scan_status,
            "created_at": scan_result.created_at,
            "vulnerabilities": [
                {
                    "type": v.vulnerability_type,
                    "severity": v.severity,
                    "line_number": v.line_number,
                    "description": v.description,
                    "recommendation": v.recommendation
                }
                for v in vulnerabilities
            ]
        }
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Failed to get scan result: {str(e)}")
        raise HTTPException(status_code=500, detail="Failed to retrieve scan result")

@app.get("/stats")
async def get_stats(db: Session = Depends(get_db)):
    """Get scanning statistics"""
    try:
        total_scans = db.query(ScanResult).count()
        total_vulnerabilities = db.query(VulnerabilityReport).count()
        
        return {
            "total_scans": total_scans,
            "total_vulnerabilities": total_vulnerabilities,
            "model_status": scanner.is_model_ready(),
            "dataset_status": dataset_loader.is_dataset_loaded()
        }
    except Exception as e:
        logger.error(f"Failed to get stats: {str(e)}")
        raise HTTPException(status_code=500, detail="Failed to retrieve statistics")

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)